/**
 * Header - مقاول توريد نخيل السعودية
 * التصميم: شريط تنقل ثابت شفاف يتحول إلى معتم عند التمرير
 * الألوان: أخضر داكن + ذهبي ملكي
 */
import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Menu, X, Phone, MessageCircle, ChevronDown } from "lucide-react";

const navItems = [
  { label: "الرئيسية", href: "/" },
  {
    label: "خدماتنا",
    href: "/services",
    children: [
      { label: "توريد النخيل", href: "/services/supply" },
      { label: "زراعة النخيل", href: "/services/planting" },
      { label: "نقل النخيل", href: "/services/transport" },
      { label: "بيع النخيل الكبير", href: "/services/large-palms" },
      { label: "نخيل للفلل والقصور", href: "/services/villas" },
      { label: "نخيل للمشاريع الحكومية", href: "/services/government" },
      { label: "تنسيق المواقع", href: "/services/landscaping" },
    ],
  },
  {
    label: "أنواع النخيل",
    href: "/palm-types",
    children: [
      { label: "نخيل سكري", href: "/palm-types/sukkari" },
      { label: "نخيل خلاص", href: "/palm-types/khallas" },
      { label: "نخيل برحي", href: "/palm-types/barhi" },
      { label: "نخيل مجدول", href: "/palm-types/medjool" },
      { label: "نخيل واشنطونيا", href: "/palm-types/washingtonia" },
      { label: "نخيل كناري", href: "/palm-types/canary" },
    ],
  },
  {
    label: "مناطق الخدمة",
    href: "/cities",
    children: [
      { label: "الرياض", href: "/cities/riyadh" },
      { label: "جدة", href: "/cities/jeddah" },
      { label: "مكة المكرمة", href: "/cities/mecca" },
      { label: "المدينة المنورة", href: "/cities/madinah" },
      { label: "الدمام", href: "/cities/dammam" },
      { label: "الخبر", href: "/cities/khobar" },
      { label: "الأحساء", href: "/cities/ahsa" },
      { label: "القصيم", href: "/cities/qassim" },
      { label: "حائل", href: "/cities/hail" },
      { label: "تبوك", href: "/cities/tabuk" },
      { label: "أبها", href: "/cities/abha" },
      { label: "جازان", href: "/cities/jazan" },
    ],
  },
  { label: "مشاريعنا", href: "/projects" },
  { label: "المدونة", href: "/blog" },
  { label: "تواصل معنا", href: "/contact" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setOpenDropdown(null);
  }, [location]);

  const isHome = location === "/";

  return (
    <header
      className={`fixed top-0 right-0 left-0 z-50 transition-all duration-300 ${
        scrolled || !isHome
          ? "bg-[#1a3d2b]/97 backdrop-blur-md shadow-lg"
          : "bg-transparent"
      }`}
    >
      {/* شريط علوي صغير */}
      <div className="bg-[#c9a84c] text-[#1a3d2b] text-center py-1.5 text-sm font-bold hidden md:block" style={{fontFamily:'Cairo,sans-serif'}}>
        📞 اتصل الآن للحصول على عرض سعر مجاني — نخدم جميع مناطق المملكة
      </div>

      <nav className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* الشعار */}
          <Link href="/" className="flex items-center gap-3 group">
            {/* رمز النخلة الهندسي الذهبي */}
            <div className="w-11 h-11 lg:w-13 lg:h-13 rounded-xl bg-[#0d2418] border-2 border-[#c9a84c]/60 group-hover:border-[#c9a84c] transition-all duration-300 flex items-center justify-center shrink-0 group-hover:shadow-[0_0_16px_rgba(201,168,76,0.3)]">
              <svg viewBox="0 0 40 44" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" aria-hidden="true">
                {/* جذع النخلة */}
                <rect x="18.5" y="22" width="3" height="18" rx="1.5" fill="#c9a84c"/>
                {/* السعف الأوسط */}
                <path d="M20 22 C20 14 20 8 20 4" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round"/>
                {/* السعف الأيمن */}
                <path d="M20 18 C24 14 28 12 32 10" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                <path d="M20 16 C23 11 26 8 30 6" stroke="#e8c96b" strokeWidth="1" strokeLinecap="round" opacity="0.7"/>
                {/* السعف الأيسر */}
                <path d="M20 18 C16 14 12 12 8 10" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                <path d="M20 16 C17 11 14 8 10 6" stroke="#e8c96b" strokeWidth="1" strokeLinecap="round" opacity="0.7"/>
                {/* السعف الأمامي */}
                <path d="M20 20 C25 17 29 16 34 15" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                <path d="M20 20 C15 17 11 16 6 15" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                {/* قاعدة الجذع */}
                <ellipse cx="20" cy="40" rx="5" ry="1.5" fill="#c9a84c" opacity="0.4"/>
              </svg>
            </div>
            <div className="text-right">
              <div className="text-[#c9a84c] font-extrabold text-base lg:text-lg leading-tight" style={{fontFamily:'Cairo,sans-serif'}}>
                مقاول توريد نخيل
              </div>
              <div className="text-white/70 text-xs" style={{fontFamily:'Tajawal,sans-serif'}}>
                السعودية
              </div>
            </div>
          </Link>

          {/* روابط التنقل - سطح المكتب */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <div key={item.href} className="relative group">
                {item.children ? (
                  <button
                    className="flex items-center gap-1 text-white/90 hover:text-[#c9a84c] px-3 py-2 text-sm font-semibold transition-colors duration-200"
                    style={{fontFamily:'Cairo,sans-serif'}}
                    onMouseEnter={() => setOpenDropdown(item.label)}
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    {item.label}
                    <ChevronDown className="w-3.5 h-3.5 transition-transform group-hover:rotate-180" />
                  </button>
                ) : (
                  <Link
                    href={item.href}
                    className="text-white/90 hover:text-[#c9a84c] px-3 py-2 text-sm font-semibold transition-colors duration-200 block"
                    style={{fontFamily:'Cairo,sans-serif'}}
                  >
                    {item.label}
                  </Link>
                )}

                {/* Dropdown */}
                {item.children && (
                  <div
                    className={`absolute top-full right-0 mt-1 bg-[#1a3d2b] border border-[#c9a84c]/20 rounded-xl shadow-2xl min-w-[200px] py-2 transition-all duration-200 origin-top-right ${
                      openDropdown === item.label
                        ? "opacity-100 scale-100 pointer-events-auto"
                        : "opacity-0 scale-95 pointer-events-none"
                    }`}
                    onMouseEnter={() => setOpenDropdown(item.label)}
                    onMouseLeave={() => setOpenDropdown(null)}
                  >
                    {item.children.map((child) => (
                      <Link
                        key={child.href}
                        href={child.href}
                        className="block px-4 py-2.5 text-white/85 hover:text-[#c9a84c] hover:bg-white/5 text-sm transition-colors"
                        style={{fontFamily:'Tajawal,sans-serif'}}
                      >
                        {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* أزرار التواصل - سطح المكتب */}
          <div className="hidden lg:flex items-center gap-2">
            <a
              href="tel:+966500000000"
              className="flex items-center gap-2 bg-[#c9a84c] hover:bg-[#e8c96b] text-[#1a3d2b] px-4 py-2 rounded-lg font-bold text-sm transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 active:scale-95"
              style={{fontFamily:'Cairo,sans-serif'}}
            >
              <Phone className="w-4 h-4" />
              اتصل الآن
            </a>
            <a
              href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20bd5a] text-white px-4 py-2 rounded-lg font-bold text-sm transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5 active:scale-95"
              style={{fontFamily:'Cairo,sans-serif'}}
            >
              <MessageCircle className="w-4 h-4" />
              واتساب
            </a>
          </div>

          {/* زر القائمة - الجوال */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden text-white p-2 rounded-lg hover:bg-white/10 transition-colors"
            aria-label="القائمة"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* القائمة المتنقلة */}
      {mobileOpen && (
        <div className="lg:hidden bg-[#1a3d2b] border-t border-[#c9a84c]/20 max-h-[80vh] overflow-y-auto">
          <div className="container py-4 space-y-1">
            {navItems.map((item) => (
              <div key={item.href}>
                {item.children ? (
                  <div>
                    <button
                      onClick={() => setOpenDropdown(openDropdown === item.label ? null : item.label)}
                      className="w-full flex items-center justify-between text-white/90 hover:text-[#c9a84c] px-4 py-3 text-base font-semibold transition-colors"
                      style={{fontFamily:'Cairo,sans-serif'}}
                    >
                      {item.label}
                      <ChevronDown className={`w-4 h-4 transition-transform ${openDropdown === item.label ? 'rotate-180' : ''}`} />
                    </button>
                    {openDropdown === item.label && (
                      <div className="bg-white/5 rounded-lg mx-2 mb-2">
                        {item.children.map((child) => (
                          <Link
                            key={child.href}
                            href={child.href}
                            className="block px-6 py-2.5 text-white/75 hover:text-[#c9a84c] text-sm transition-colors"
                            style={{fontFamily:'Tajawal,sans-serif'}}
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  <Link
                    href={item.href}
                    className="block text-white/90 hover:text-[#c9a84c] px-4 py-3 text-base font-semibold transition-colors"
                    style={{fontFamily:'Cairo,sans-serif'}}
                  >
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
            <div className="flex gap-3 pt-4 px-4">
              <a
                href="tel:+966500000000"
                className="flex-1 flex items-center justify-center gap-2 bg-[#c9a84c] text-[#1a3d2b] py-3 rounded-lg font-bold text-sm"
                style={{fontFamily:'Cairo,sans-serif'}}
              >
                <Phone className="w-4 h-4" />
                اتصل الآن
              </a>
              <a
                href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 flex items-center justify-center gap-2 bg-[#25D366] text-white py-3 rounded-lg font-bold text-sm"
                style={{fontFamily:'Cairo,sans-serif'}}
              >
                <MessageCircle className="w-4 h-4" />
                واتساب
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
