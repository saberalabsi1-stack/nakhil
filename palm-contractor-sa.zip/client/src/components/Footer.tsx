/**
 * Footer - مقاول توريد نخيل السعودية
 * تصميم داكن فاخر مع روابط وبيانات التواصل
 */
import { Link } from "wouter";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-[#0d2418] text-white" style={{fontFamily:'Tajawal,sans-serif'}}>
      {/* قسم CTA قبل الفوتر */}
      <div className="bg-gradient-to-r from-[#c9a84c] to-[#e8c96b] py-10">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl lg:text-3xl font-extrabold text-[#1a3d2b] mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            هل تحتاج نخيلاً لمشروعك؟ تواصل معنا الآن
          </h2>
          <p className="text-[#1a3d2b]/80 mb-6 text-lg">
            نوفر أجود أنواع النخيل مع خدمات النقل والزراعة في جميع مناطق المملكة
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+966500000000"
              className="inline-flex items-center justify-center gap-2 bg-[#1a3d2b] text-white px-8 py-3.5 rounded-xl font-bold text-lg hover:bg-[#2d6a4f] transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5"
              style={{fontFamily:'Cairo,sans-serif'}}
            >
              <Phone className="w-5 h-5" />
              اتصل الآن
            </a>
            <a
              href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-8 py-3.5 rounded-xl font-bold text-lg hover:bg-[#20bd5a] transition-all duration-200 hover:shadow-xl hover:-translate-y-0.5"
              style={{fontFamily:'Cairo,sans-serif'}}
            >
              <MessageCircle className="w-5 h-5" />
              راسلنا على واتساب
            </a>
          </div>
        </div>
      </div>

      {/* محتوى الفوتر */}
      <div className="container mx-auto px-4 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* عن الشركة */}
          <div>
            <div className="flex items-center gap-3 mb-5">
              {/* رمز النخلة الهندسي */}
              <div className="w-11 h-11 rounded-xl bg-[#1a3d2b] border-2 border-[#c9a84c]/50 flex items-center justify-center shrink-0">
                <svg viewBox="0 0 40 44" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-7 h-7" aria-hidden="true">
                  <rect x="18.5" y="22" width="3" height="18" rx="1.5" fill="#c9a84c"/>
                  <path d="M20 22 C20 14 20 8 20 4" stroke="#c9a84c" strokeWidth="2" strokeLinecap="round"/>
                  <path d="M20 18 C24 14 28 12 32 10" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M20 16 C23 11 26 8 30 6" stroke="#e8c96b" strokeWidth="1" strokeLinecap="round" opacity="0.7"/>
                  <path d="M20 18 C16 14 12 12 8 10" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M20 16 C17 11 14 8 10 6" stroke="#e8c96b" strokeWidth="1" strokeLinecap="round" opacity="0.7"/>
                  <path d="M20 20 C25 17 29 16 34 15" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                  <path d="M20 20 C15 17 11 16 6 15" stroke="#c9a84c" strokeWidth="1.5" strokeLinecap="round"/>
                  <ellipse cx="20" cy="40" rx="5" ry="1.5" fill="#c9a84c" opacity="0.4"/>
                </svg>
              </div>
              <div>
                <div className="text-[#c9a84c] font-extrabold text-base" style={{fontFamily:'Cairo,sans-serif'}}>مقاول توريد نخيل</div>
                <div className="text-white/60 text-xs">السعودية</div>
              </div>
            </div>
            <p className="text-white/70 text-sm leading-relaxed mb-5">
              متخصصون في توريد وزراعة ونقل النخيل في جميع مناطق المملكة العربية السعودية. نقدم أجود أنواع النخيل للمشاريع الحكومية والفلل والاستراحات والمنتجعات.
            </p>
            <div className="space-y-2.5">
              <div className="flex items-center gap-2 text-white/70 text-sm">
                <MapPin className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span>المملكة العربية السعودية — جميع المناطق</span>
              </div>
              <div className="flex items-center gap-2 text-white/70 text-sm">
                <Clock className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span>السبت – الخميس: 8 صباحاً – 6 مساءً</span>
              </div>
              <a href="tel:+966500000000" className="flex items-center gap-2 text-white/70 hover:text-[#c9a84c] text-sm transition-colors">
                <Phone className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span dir="ltr">+966 50 000 0000</span>
              </a>
              <a href="mailto:info@palm-contractor.sa" className="flex items-center gap-2 text-white/70 hover:text-[#c9a84c] text-sm transition-colors">
                <Mail className="w-4 h-4 text-[#c9a84c] shrink-0" />
                <span>info@palm-contractor.sa</span>
              </a>
            </div>
          </div>

          {/* خدماتنا */}
          <div>
            <h3 className="text-[#c9a84c] font-bold text-lg mb-5" style={{fontFamily:'Cairo,sans-serif'}}>خدماتنا</h3>
            <ul className="space-y-2.5">
              {[
                { label: "توريد النخيل", href: "/services/supply" },
                { label: "زراعة النخيل", href: "/services/planting" },
                { label: "نقل النخيل", href: "/services/transport" },
                { label: "بيع النخيل الكبير", href: "/services/large-palms" },
                { label: "نخيل للفلل والقصور", href: "/services/villas" },
                { label: "نخيل للمشاريع الحكومية", href: "/services/government" },
                { label: "تنسيق المواقع بالنخيل", href: "/services/landscaping" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-white/70 hover:text-[#c9a84c] text-sm transition-colors flex items-center gap-2">
                    <span className="text-[#c9a84c] text-xs">◆</span>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* أنواع النخيل */}
          <div>
            <h3 className="text-[#c9a84c] font-bold text-lg mb-5" style={{fontFamily:'Cairo,sans-serif'}}>أنواع النخيل</h3>
            <ul className="space-y-2.5">
              {[
                { label: "نخيل سكري", href: "/palm-types/sukkari" },
                { label: "نخيل خلاص", href: "/palm-types/khallas" },
                { label: "نخيل برحي", href: "/palm-types/barhi" },
                { label: "نخيل مجدول", href: "/palm-types/medjool" },
                { label: "نخيل واشنطونيا", href: "/palm-types/washingtonia" },
                { label: "نخيل كناري", href: "/palm-types/canary" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-white/70 hover:text-[#c9a84c] text-sm transition-colors flex items-center gap-2">
                    <span className="text-[#c9a84c] text-xs">◆</span>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
            <h3 className="text-[#c9a84c] font-bold text-lg mt-6 mb-4" style={{fontFamily:'Cairo,sans-serif'}}>روابط سريعة</h3>
            <ul className="space-y-2.5">
              {[
                { label: "مشاريعنا", href: "/projects" },
                { label: "المدونة", href: "/blog" },
                { label: "تواصل معنا", href: "/contact" },
                { label: "اطلب عرض سعر", href: "/contact#quote" },
              ].map((item) => (
                <li key={item.href}>
                  <Link href={item.href} className="text-white/70 hover:text-[#c9a84c] text-sm transition-colors flex items-center gap-2">
                    <span className="text-[#c9a84c] text-xs">◆</span>
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* مناطق الخدمة */}
          <div>
            <h3 className="text-[#c9a84c] font-bold text-lg mb-5" style={{fontFamily:'Cairo,sans-serif'}}>مناطق الخدمة</h3>
            <div className="grid grid-cols-2 gap-2">
              {[
                { label: "الرياض", href: "/cities/riyadh" },
                { label: "جدة", href: "/cities/jeddah" },
                { label: "مكة المكرمة", href: "/cities/mecca" },
                { label: "المدينة المنورة", href: "/cities/madinah" },
                { label: "الدمام", href: "/cities/dammam" },
                { label: "الخبر", href: "/cities/khobar" },
                { label: "الأحساء", href: "/cities/ahsa" },
                { label: "القصيم", href: "/cities/qassim" },
                { label: "حائل", href: "/cities/hail" },
                { label: "تبوك", href: "/cities/tabuk" },
                { label: "أبها", href: "/cities/abha" },
                { label: "جازان", href: "/cities/jazan" },
              ].map((item) => (
                <Link key={item.href} href={item.href} className="text-white/70 hover:text-[#c9a84c] text-sm transition-colors py-1">
                  {item.label}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* حقوق النشر */}
      <div className="border-t border-white/10 py-5">
        <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-3 text-white/50 text-sm">
          <p>© {currentYear} مقاول توريد نخيل السعودية — جميع الحقوق محفوظة</p>
          <p>تصميم واحترافي لخدمة عملائنا في جميع مناطق المملكة العربية السعودية</p>
        </div>
      </div>
    </footer>
  );
}
