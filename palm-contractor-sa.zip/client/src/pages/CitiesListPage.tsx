/**
 * CitiesListPage - صفحة فهرس المدن
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { MapPin } from "lucide-react";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const cities = [
  { name: "الرياض", href: "/cities/riyadh", desc: "العاصمة — أكبر مدن المملكة وأكثرها طلباً على النخيل" },
  { name: "جدة", href: "/cities/jeddah", desc: "عروس البحر الأحمر — مناخ ساحلي مناسب لأنواع متعددة" },
  { name: "مكة المكرمة", href: "/cities/mecca", desc: "المدينة المقدسة — نمو عمراني هائل ومشاريع كبرى" },
  { name: "المدينة المنورة", href: "/cities/madinah", desc: "موطن أجود التمور السعودية وأصل النخيل" },
  { name: "الدمام", href: "/cities/dammam", desc: "عاصمة المنطقة الشرقية — قريبة من مشاتل الأحساء" },
  { name: "الخبر", href: "/cities/khobar", desc: "مدينة راقية بمشاريع عمرانية فاخرة" },
  { name: "الأحساء", href: "/cities/ahsa", desc: "أكبر واحة نخيل في العالم — موطن أجود الأنواع" },
  { name: "القصيم", href: "/cities/qassim", desc: "قلب المملكة الزراعي وموطن النخيل الأصيل" },
  { name: "حائل", href: "/cities/hail", desc: "المنطقة الشمالية — مناخ معتدل مناسب للنخيل" },
  { name: "تبوك", href: "/cities/tabuk", desc: "بوابة الشمال الغربي — مشاريع سياحية كبرى" },
  { name: "أبها", href: "/cities/abha", desc: "عروس الجبال — مناخ بارد ومشاريع سياحية" },
  { name: "جازان", href: "/cities/jazan", desc: "المنطقة الجنوبية — مناخ استوائي دافئ" },
];

export default function CitiesListPage() {
  useScrollReveal();
  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">مناطق الخدمة</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>مناطق خدمتنا</h1>
          <p className="text-white/70 mt-2">نخدم جميع مناطق المملكة العربية السعودية</p>
        </div>
      </section>

      <section className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {cities.map((city, i) => (
              <Link
                key={city.href}
                href={city.href}
                className="service-card p-6 flex items-start gap-4 group fade-in-up"
                style={{ transitionDelay: `${i * 50}ms` }}
              >
                <div className="w-12 h-12 bg-[#1a3d2b]/10 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-[#1a3d2b] transition-colors">
                  <MapPin className="w-5 h-5 text-[#1a3d2b] group-hover:text-[#c9a84c] transition-colors" />
                </div>
                <div>
                  <h2 className="font-bold text-[#1a3d2b] text-lg group-hover:text-[#c9a84c] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>{city.name}</h2>
                  <p className="text-gray-600 text-sm mt-1">{city.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
