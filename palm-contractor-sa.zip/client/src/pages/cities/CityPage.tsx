/**
 * CityPage - صفحة مدينة عامة
 * تُستخدم لجميع صفحات المدن الـ 12
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle, CheckCircle, MapPin } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";
import SEOHead, { buildCitySchema, buildFAQSchema, buildBreadcrumbSchema } from "@/components/SEOHead";

interface CityPageProps {
  cityName: string;
  citySlug: string;
  description: string;
  content: string[];
  services: string[];
  faqs: { q: string; a: string }[];
}

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

export default function CityPage({ cityName, citySlug, description, content, services, faqs }: CityPageProps) {
  useScrollReveal();

  const schemas = [
    buildCitySchema(cityName, citySlug),
    buildFAQSchema(faqs),
    buildBreadcrumbSchema([
      { name: 'الرئيسية', url: '/' },
      { name: 'مناطق الخدمة', url: '/cities' },
      { name: cityName, url: `/cities/${citySlug}` },
    ]),
  ];

  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <SEOHead
        title={`مقاول توريد وزراعة ونقل النخيل في ${cityName}`}
        description={description.slice(0, 160)}
        keywords={`مقاول نخيل ${cityName}, توريد نخيل ${cityName}, زراعة نخيل ${cityName}, نقل نخيل ${cityName}, نخيل للبيع ${cityName}`}
        canonical={`/cities/${citySlug}`}
        schema={schemas}
      />
      {/* Hero */}
      <section className="relative h-72 lg:h-96 flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img src="/manus-storage/hero-palms_f04092c0.jpg" alt={`نخيل ${cityName}`} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b]/60 to-[#0d2418]/90" />
        </div>
        <div className="relative z-10 container mx-auto px-4 pb-12 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <Link href="/cities" className="hover:text-[#c9a84c]">مناطق الخدمة</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">{cityName}</span>
          </nav>
          <div className="flex items-center gap-3 mb-3">
            <MapPin className="w-6 h-6 text-[#c9a84c]" />
            <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>
              توريد وزراعة ونقل النخيل في {cityName}
            </h1>
          </div>
          <p className="text-white/80 text-lg">خدمات نخيل احترافية في {cityName} وجميع أحياء المنطقة</p>
        </div>
      </section>

      {/* CTA شريط */}
      <div className="bg-[#c9a84c] py-4">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[#1a3d2b] font-bold" style={{fontFamily:'Cairo,sans-serif'}}>
            هل تبحث عن مقاول نخيل في {cityName}؟ اتصل بنا الآن
          </p>
          <div className="flex gap-3">
            <a href="tel:+966500000000" className="flex items-center gap-2 bg-[#1a3d2b] text-white px-5 py-2 rounded-lg font-bold text-sm hover:bg-[#2d6a4f] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
              <Phone className="w-4 h-4" /> اتصل الآن
            </a>
            <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-[#25D366] text-white px-5 py-2 rounded-lg font-bold text-sm" style={{fontFamily:'Cairo,sans-serif'}}>
              <MessageCircle className="w-4 h-4" /> واتساب
            </a>
          </div>
        </div>
      </div>

      {/* المحتوى */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-8">
              <div className="fade-in-up">
                <p className="text-gray-700 leading-relaxed text-lg">{description}</p>
              </div>

              {/* الخدمات في المدينة */}
              <div className="fade-in-up">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                  خدماتنا في {cityName}
                </h2>
                <div className="gold-accent-line mb-6"></div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {services.map((s, i) => (
                    <div key={i} className="flex items-center gap-3 bg-[#faf8f3] rounded-xl p-4">
                      <CheckCircle className="w-5 h-5 text-[#c9a84c] shrink-0" />
                      <span className="text-gray-700 text-sm font-medium">{s}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* المحتوى */}
              {content.map((para, i) => (
                <div key={i} className="fade-in-up">
                  <p className="text-gray-700 leading-relaxed">{para}</p>
                </div>
              ))}

              {/* الأسئلة الشائعة */}
              <div className="fade-in-up">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                  أسئلة شائعة — النخيل في {cityName}
                </h2>
                <div className="gold-accent-line mb-6"></div>
                <div className="space-y-3">
                  {faqs.map((faq, i) => (
                    <div key={i} className="border border-[#c9a84c]/20 rounded-xl overflow-hidden">
                      <details className="group">
                        <summary className="flex items-center justify-between p-4 cursor-pointer bg-[#faf8f3] hover:bg-[#f0ece0] transition-colors">
                          <span className="font-bold text-[#1a3d2b] text-sm" style={{fontFamily:'Cairo,sans-serif'}}>{faq.q}</span>
                          <span className="text-[#c9a84c] text-xl font-bold group-open:rotate-45 transition-transform">+</span>
                        </summary>
                        <div className="p-4 text-gray-700 text-sm leading-relaxed border-t border-[#c9a84c]/10">{faq.a}</div>
                      </details>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* الشريط الجانبي */}
            <div className="space-y-6">
              <div className="bg-[#1a3d2b] rounded-2xl p-6 sticky top-24">
                <QuoteForm title={`اطلب عرض سعر في ${cityName}`} subtitle="نرد خلال ساعات" dark={true} />
              </div>
              <div className="bg-[#faf8f3] rounded-2xl p-6">
                <h3 className="text-lg font-bold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>خدماتنا</h3>
                <div className="space-y-2">
                  {[
                    { title: "توريد النخيل", href: "/services/supply" },
                    { title: "زراعة النخيل", href: "/services/planting" },
                    { title: "نقل النخيل", href: "/services/transport" },
                    { title: "نخيل للفلل", href: "/services/villas" },
                    { title: "نخيل للمشاريع الحكومية", href: "/services/government" },
                  ].map((s) => (
                    <Link key={s.href} href={s.href} className="flex items-center justify-between p-3 bg-white rounded-xl hover:bg-[#1a3d2b] hover:text-white group transition-all">
                      <span className="text-sm font-semibold text-[#1a3d2b] group-hover:text-white" style={{fontFamily:'Cairo,sans-serif'}}>{s.title}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
