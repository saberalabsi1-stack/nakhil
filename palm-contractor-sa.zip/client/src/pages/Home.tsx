/**
 * Home - الصفحة الرئيسية
 * مقاول توريد نخيل السعودية
 * التصميم: التراث والمعاصرة — أخضر داكن + ذهبي ملكي
 * زخرفة هندسية مستوحاة من سعف النخيل، إطارات ذهبية، هيرو سينمائي
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle, CheckCircle, Star, ArrowLeft, Truck, Sprout, TreePine, Building2, Home as HomeIcon, Landmark, Palette, MapPin } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";
import SEOHead, { buildBreadcrumbSchema } from "@/components/SEOHead";

// Hook لتأثير الظهور عند التمرير
function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          }
        });
      },
      { threshold: 0.08, rootMargin: "0px 0px -40px 0px" }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const services = [
  { icon: Truck, title: "توريد النخيل", desc: "نوفر أجود أنواع النخيل من مختلف المناطق بأسعار تنافسية مع ضمان الجودة والحيوية", href: "/services/supply" },
  { icon: Sprout, title: "زراعة النخيل", desc: "فريق متخصص في زراعة النخيل بالطرق الصحيحة لضمان نمو صحي وطويل الأمد", href: "/services/planting" },
  { icon: Truck, title: "نقل النخيل", desc: "نقل آمن للنخيل بمعدات متخصصة وسيارات مجهزة للحفاظ على سلامة النخلة", href: "/services/transport" },
  { icon: TreePine, title: "بيع النخيل الكبير", desc: "نخيل كبير ومعمّر بأحجام مختلفة مناسب للمشاريع الكبرى والمداخل الفاخرة", href: "/services/large-palms" },
  { icon: HomeIcon, title: "نخيل للفلل والقصور", desc: "حلول متكاملة لتزيين الفلل والقصور والاستراحات بأجمل أنواع النخيل", href: "/services/villas" },
  { icon: Landmark, title: "نخيل للمشاريع الحكومية", desc: "خبرة واسعة في تنفيذ مشاريع التشجير الحكومية والبنية التحتية", href: "/services/government" },
  { icon: Palette, title: "تنسيق المواقع بالنخيل", desc: "تصميم وتنسيق المواقع والحدائق بالنخيل لإبراز الجمال الطبيعي", href: "/services/landscaping" },
];

const palmTypes = [
  { name: "نخيل سكري", desc: "من أشهر أنواع النخيل السعودية، يتميز بتمره الحلو ومظهره الجميل", href: "/palm-types/sukkari", img: "/manus-storage/palm-nursery_1b1f6210.jpg" },
  { name: "نخيل خلاص", desc: "نخيل فاخر ذو قيمة عالية، مطلوب للمشاريع الراقية والفلل الفاخرة", href: "/palm-types/khallas", img: "/manus-storage/hero-palms_f04092c0.jpg" },
  { name: "نخيل برحي", desc: "نخيل متوسط الحجم بتمر ذهبي اللون، مناسب للحدائق والمداخل", href: "/palm-types/barhi", img: "/manus-storage/villa-palms_9becb0e1.jpg" },
  { name: "نخيل مجدول", desc: "ملك النخيل، يتميز بتمره الكبير وجذعه الجميل المناسب للمشاريع الفاخرة", href: "/palm-types/medjool", img: "/manus-storage/palm-transplant_e04f8b1e.jpg" },
  { name: "نخيل واشنطونيا", desc: "نخيل زينة طويل وأنيق، مثالي لتزيين الشوارع والمداخل والمشاريع الكبرى", href: "/palm-types/washingtonia", img: "/manus-storage/hero-palms_f04092c0.jpg" },
  { name: "نخيل كناري", desc: "نخيل زينة فاخر بسعف كثيف وجذع مميز، يضفي طابعاً استوائياً راقياً", href: "/palm-types/canary", img: "/manus-storage/villa-palms_9becb0e1.jpg" },
];

const cities = [
  { name: "الرياض", href: "/cities/riyadh" },
  { name: "جدة", href: "/cities/jeddah" },
  { name: "مكة المكرمة", href: "/cities/mecca" },
  { name: "المدينة المنورة", href: "/cities/madinah" },
  { name: "الدمام", href: "/cities/dammam" },
  { name: "الخبر", href: "/cities/khobar" },
  { name: "الأحساء", href: "/cities/ahsa" },
  { name: "القصيم", href: "/cities/qassim" },
  { name: "حائل", href: "/cities/hail" },
  { name: "تبوك", href: "/cities/tabuk" },
  { name: "أبها", href: "/cities/abha" },
  { name: "جازان", href: "/cities/jazan" },
];

const stats = [
  { value: "+500", label: "مشروع منجز" },
  { value: "+15", label: "سنة خبرة" },
  { value: "12", label: "منطقة نخدمها" },
  { value: "100%", label: "رضا العملاء" },
];

const faqs = [
  { q: "ما هي مناطق خدمتكم؟", a: "نخدم جميع مناطق المملكة العربية السعودية بما فيها الرياض وجدة ومكة المكرمة والمدينة المنورة والدمام والخبر والأحساء والقصيم وحائل وتبوك وأبها وجازان ونجران." },
  { q: "هل تقدمون ضماناً على النخيل بعد الزراعة؟", a: "نعم، نقدم ضماناً على نجاح الزراعة مع متابعة دورية لضمان نمو النخيل بشكل صحي وسليم." },
  { q: "كيف يتم نقل النخيل الكبير؟", a: "نستخدم معدات ورافعات متخصصة وسيارات مجهزة خصيصاً لنقل النخيل الكبير بأمان تام مع الحفاظ على جذوره وسعفه." },
  { q: "ما هي أسعار توريد النخيل؟", a: "تتفاوت الأسعار حسب نوع النخيل وحجمه والكمية المطلوبة والمنطقة. تواصل معنا للحصول على عرض سعر مخصص لمشروعك." },
  { q: "هل تنفذون مشاريع حكومية كبرى؟", a: "نعم، لدينا خبرة واسعة في تنفيذ مشاريع التشجير الحكومية والبنية التحتية بمختلف المناطق." },
];

// مكون زخرفة سعف النخيل الهندسية
function PalmLeafDecor({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 60" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M60 55 C40 40 10 35 5 10 C20 25 35 30 60 55Z" fill="currentColor" opacity="0.6"/>
      <path d="M60 55 C80 40 110 35 115 10 C100 25 85 30 60 55Z" fill="currentColor" opacity="0.6"/>
      <path d="M60 55 C50 30 45 10 60 2 C75 10 70 30 60 55Z" fill="currentColor" opacity="0.8"/>
      <path d="M60 55 C35 45 15 50 5 35 C20 40 40 42 60 55Z" fill="currentColor" opacity="0.4"/>
      <path d="M60 55 C85 45 105 50 115 35 C100 40 80 42 60 55Z" fill="currentColor" opacity="0.4"/>
    </svg>
  );
}

// مكون الإطار الذهبي الزخرفي
function GoldFrame({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative ${className}`}>
      {/* زوايا ذهبية */}
      <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[#c9a84c]" />
      <div className="absolute top-0 left-0 w-8 h-8 border-t-2 border-l-2 border-[#c9a84c]" />
      <div className="absolute bottom-0 right-0 w-8 h-8 border-b-2 border-r-2 border-[#c9a84c]" />
      <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[#c9a84c]" />
      {children}
    </div>
  );
}

const homeSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "@id": "https://palm-contractor-sa.manus.space/",
  "name": "مقاول توريد نخيل السعودية",
  "description": "مقاول متخصص في توريد وزراعة ونقل النخيل في جميع مناطق المملكة العربية السعودية",
  "url": "https://palm-contractor-sa.manus.space/",
  "telephone": "+966500000000",
  "email": "info@palm-contractor.sa",
  "priceRange": "$$",
  "areaServed": { "@type": "Country", "name": "Saudi Arabia" },
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "خدمات النخيل",
    "itemListElement": [
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "توريد النخيل" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "زراعة النخيل" } },
      { "@type": "Offer", "itemOffered": { "@type": "Service", "name": "نقل النخيل" } },
    ]
  },
  "sameAs": ["https://wa.me/966500000000"]
};

export default function Home() {
  useScrollReveal();

  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <SEOHead
        title="مقاول توريد وزراعة ونقل النخيل في السعودية | مقاول توريد نخيل السعودية"
        description="مقاول متخصص في توريد وزراعة ونقل النخيل في جميع مناطق المملكة العربية السعودية. نوفر أجود أنواع النخيل للمشاريع الحكومية والفلل والاستراحات والمنتجعات."
        keywords="مقاول توريد نخيل, توريد نخيل بالرياض, زراعة نخيل, نقل نخيل, شراء نخيل, نخيل للبيع, مقاول نخيل, توريد نخيل للمشاريع, نقل وزراعة النخيل"
        canonical="/"
        schema={[homeSchema, buildBreadcrumbSchema([{ name: 'الرئيسية', url: '/' }])]}
      />

      {/* ===== قسم Hero ===== */}
      <section className="relative min-h-screen flex items-center overflow-hidden">
        {/* خلفية الصورة */}
        <div className="absolute inset-0">
          <img
            src="/manus-storage/hero-palms_f04092c0.jpg"
            alt="نخيل سعودي فاخر"
            className="w-full h-full object-cover"
            loading="eager"
          />
          {/* تدرج متعدد الطبقات للعمق */}
          <div className="absolute inset-0" style={{background: 'linear-gradient(105deg, rgba(13,36,24,0.92) 0%, rgba(13,36,24,0.75) 45%, rgba(13,36,24,0.55) 100%)'}} />
          {/* نمط هندسي خفيف */}
          <div className="absolute inset-0 palm-pattern opacity-20" />
        </div>

        {/* زخرفة سعف النخيل في الزاوية */}
        <div className="absolute top-24 left-0 w-64 h-32 text-[#c9a84c]/10 pointer-events-none hidden lg:block">
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="absolute bottom-16 right-0 w-48 h-24 text-[#c9a84c]/10 pointer-events-none hidden lg:block" style={{transform: 'scaleX(-1)'}}>
          <PalmLeafDecor className="w-full h-full" />
        </div>

        {/* محتوى Hero — تخطيط غير متماثل */}
        <div className="relative z-10 container mx-auto px-4 pt-32 pb-20">
          <div className="max-w-3xl">
            {/* شارة الثقة */}
            <div className="inline-flex items-center gap-2 bg-[#c9a84c]/15 border border-[#c9a84c]/35 rounded-full px-5 py-2 mb-8 backdrop-blur-sm">
              <Star className="w-4 h-4 text-[#c9a84c]" fill="#c9a84c" />
              <span className="text-[#c9a84c] text-sm font-bold" style={{fontFamily:'Cairo,sans-serif'}}>
                أكثر من 500 مشروع ناجح في المملكة
              </span>
            </div>

            {/* العنوان الرئيسي مع خط ذهبي */}
            <div className="mb-2">
              <div className="w-16 h-1 bg-gradient-to-l from-[#c9a84c] to-[#e8c96b] mb-5 rounded-full" />
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-7xl font-extrabold leading-tight mb-6 text-white" style={{fontFamily:'Cairo,sans-serif', lineHeight: '1.15'}}>
              مقاول توريد وزراعة
              <br />
              ونقل النخيل
              <br />
              <span className="text-[#c9a84c] relative">
                في جميع مناطق السعودية
                <span className="absolute -bottom-1 right-0 left-0 h-0.5 bg-gradient-to-l from-transparent via-[#c9a84c]/60 to-transparent" />
              </span>
            </h1>

            <p className="text-lg lg:text-xl text-white/80 max-w-2xl mb-10 leading-relaxed">
              نوفر أجود أنواع النخيل للمشاريع الحكومية والفلل والاستراحات والمنتجعات
              مع خدمات النقل والزراعة والتركيب الاحترافية
            </p>

            {/* أزرار CTA */}
            <div className="flex flex-wrap gap-4 mb-14">
              <a
                href="tel:+966500000000"
                className="inline-flex items-center justify-center gap-3 bg-[#c9a84c] hover:bg-[#e8c96b] text-[#1a3d2b] px-8 py-4 rounded-xl font-extrabold text-lg transition-all duration-200 hover:shadow-[0_8px_30px_rgba(201,168,76,0.4)] hover:-translate-y-1 active:scale-95"
                style={{fontFamily:'Cairo,sans-serif'}}
              >
                <Phone className="w-5 h-5" />
                اتصل الآن
              </a>
              <a
                href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-3 bg-[#25D366] hover:bg-[#20bd5a] text-white px-8 py-4 rounded-xl font-extrabold text-lg transition-all duration-200 hover:shadow-[0_8px_30px_rgba(37,211,102,0.35)] hover:-translate-y-1 active:scale-95"
                style={{fontFamily:'Cairo,sans-serif'}}
              >
                <MessageCircle className="w-5 h-5" />
                واتساب
              </a>
              <Link
                href="/contact#quote"
                className="inline-flex items-center justify-center gap-3 bg-transparent hover:bg-white/10 border-2 border-[#c9a84c]/60 hover:border-[#c9a84c] text-white px-8 py-4 rounded-xl font-extrabold text-lg transition-all duration-200 backdrop-blur-sm hover:-translate-y-1"
                style={{fontFamily:'Cairo,sans-serif'}}
              >
                اطلب عرض سعر
              </Link>
            </div>

            {/* إحصائيات */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl">
              {stats.map((stat) => (
                <div key={stat.label} className="relative">
                  <div className="absolute top-0 right-0 w-5 h-5 border-t border-r border-[#c9a84c]/50" />
                  <div className="absolute bottom-0 left-0 w-5 h-5 border-b border-l border-[#c9a84c]/50" />
                  <div className="bg-white/8 backdrop-blur-sm border border-white/15 rounded-lg py-4 px-3 text-center">
                    <div className="text-3xl font-extrabold text-[#c9a84c]" style={{fontFamily:'Cairo,sans-serif'}}>{stat.value}</div>
                    <div className="text-white/70 text-xs mt-1">{stat.label}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* سهم للأسفل */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-8 h-8 border-2 border-[#c9a84c]/50 rounded-full flex items-center justify-center">
            <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
          </div>
        </div>
      </section>

      {/* ===== شريط الثقة ===== */}
      <div className="bg-[#1a3d2b] border-y border-[#c9a84c]/20 py-5">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-center gap-8 text-white/80 text-sm">
            {["✓ ضمان الجودة", "✓ توريد لجميع المناطق", "✓ خبرة +15 سنة", "✓ أسعار تنافسية", "✓ متابعة ما بعد البيع"].map((item) => (
              <span key={item} className="font-semibold text-[#c9a84c]" style={{fontFamily:'Cairo,sans-serif'}}>{item}</span>
            ))}
          </div>
        </div>
      </div>

      {/* ===== قسم الخدمات ===== */}
      <section className="py-24 bg-[#faf8f3] relative overflow-hidden">
        {/* زخرفة خلفية */}
        <div className="absolute top-0 left-0 w-72 h-72 text-[#1a3d2b]/4 pointer-events-none">
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 fade-in-up">
            <span className="text-[#c9a84c] font-bold text-xs uppercase tracking-[0.3em]" style={{fontFamily:'Cairo,sans-serif'}}>خدماتنا المتكاملة</span>
            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#1a3d2b] mt-3 mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
              كل ما تحتاجه في عالم النخيل
            </h2>
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="h-px w-16 bg-gradient-to-l from-[#c9a84c] to-transparent" />
              <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
              <div className="h-px w-16 bg-gradient-to-r from-[#c9a84c] to-transparent" />
            </div>
            <p className="text-gray-600 max-w-2xl mx-auto leading-relaxed">
              نقدم خدمات متكاملة من التوريد والزراعة والنقل وصولاً إلى التنسيق الاحترافي للمواقع
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {services.map((service, i) => (
              <Link
                key={service.href}
                href={service.href}
                className="group relative bg-white border border-[#c9a84c]/15 rounded-2xl p-6 fade-in-up overflow-hidden transition-all duration-300 hover:-translate-y-2 hover:shadow-[0_16px_48px_rgba(26,61,43,0.15)] hover:border-[#c9a84c]/40"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                {/* إطار ذهبي عند الـ hover */}
                <div className="absolute top-0 right-0 w-8 h-8 border-t-2 border-r-2 border-[#c9a84c]/0 group-hover:border-[#c9a84c]/60 transition-all duration-300" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-2 border-l-2 border-[#c9a84c]/0 group-hover:border-[#c9a84c]/60 transition-all duration-300" />
                {/* خط ذهبي علوي */}
                <div className="absolute top-0 right-0 left-0 h-0.5 bg-gradient-to-l from-transparent via-[#c9a84c]/0 to-transparent group-hover:via-[#c9a84c]/50 transition-all duration-300" />

                <div className="w-14 h-14 bg-gradient-to-br from-[#1a3d2b]/8 to-[#2d6a4f]/12 rounded-xl flex items-center justify-center mb-5 group-hover:bg-gradient-to-br group-hover:from-[#1a3d2b] group-hover:to-[#2d6a4f] transition-all duration-300">
                  <service.icon className="w-7 h-7 text-[#2d6a4f] group-hover:text-[#c9a84c] transition-colors duration-300" />
                </div>
                <h3 className="text-lg font-bold text-[#1a3d2b] mb-2 group-hover:text-[#1a3d2b]" style={{fontFamily:'Cairo,sans-serif'}}>
                  {service.title}
                </h3>
                <p className="text-gray-500 text-sm leading-relaxed mb-5">{service.desc}</p>
                <div className="flex items-center gap-2 text-[#c9a84c] text-sm font-bold group-hover:gap-3 transition-all duration-200" style={{fontFamily:'Cairo,sans-serif'}}>
                  <span>اعرف المزيد</span>
                  <ArrowLeft className="w-4 h-4 rotate-180" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== قسم لماذا نحن ===== */}
      <section className="py-24 section-dark relative overflow-hidden">
        {/* زخرفة سعف النخيل */}
        <div className="absolute inset-0 palm-pattern opacity-8" />
        <div className="absolute -top-20 -left-20 w-96 h-96 text-[#c9a84c]/5 pointer-events-none">
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="absolute -bottom-10 -right-10 w-72 h-72 text-[#c9a84c]/5 pointer-events-none" style={{transform:'scaleX(-1)'}}>
          <PalmLeafDecor className="w-full h-full" />
        </div>

        <div className="container mx-auto px-4 relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div className="fade-in-up">
              <span className="text-[#c9a84c] font-bold text-xs uppercase tracking-[0.3em]" style={{fontFamily:'Cairo,sans-serif'}}>لماذا تختارنا؟</span>
              <h2 className="text-3xl lg:text-5xl font-extrabold text-white mt-3 mb-4" style={{fontFamily:'Cairo,sans-serif', lineHeight:'1.2'}}>
                خبرة تمتد لأكثر من
                <span className="text-[#c9a84c]"> 15 عاماً</span>
                <br />في سوق النخيل السعودي
              </h2>
              <div className="flex items-center gap-3 mb-6">
                <div className="h-px w-16 bg-gradient-to-l from-[#c9a84c] to-transparent" />
                <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
                <div className="h-px w-16 bg-gradient-to-r from-[#c9a84c] to-transparent" />
              </div>
              <p className="text-white/70 leading-relaxed mb-8 text-lg">
                نحن مقاولون متخصصون في توريد وزراعة ونقل النخيل في جميع مناطق المملكة العربية السعودية.
                نمتلك أسطولاً من المعدات المتخصصة وفريقاً من الخبراء المدربين على أعلى مستوى.
              </p>
              <div className="space-y-4 mb-10">
                {[
                  "نخيل مضمون الجودة والحيوية من أفضل المصادر",
                  "فريق متخصص ومعدات حديثة للنقل الآمن",
                  "خدمة ما بعد البيع ومتابعة دورية",
                  "أسعار تنافسية وشفافية كاملة في التعامل",
                  "خبرة في المشاريع الحكومية والخاصة الكبرى",
                  "تغطية جميع مناطق المملكة العربية السعودية",
                ].map((point, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#c9a84c]/20 border border-[#c9a84c]/40 flex items-center justify-center shrink-0 mt-0.5">
                      <CheckCircle className="w-3 h-3 text-[#c9a84c]" />
                    </div>
                    <span className="text-white/80">{point}</span>
                  </div>
                ))}
              </div>
              <div className="flex gap-4">
                <a href="tel:+966500000000" className="btn-gold px-7 py-3.5 rounded-xl inline-flex items-center gap-2 text-base" style={{fontFamily:'Cairo,sans-serif'}}>
                  <Phone className="w-4 h-4" />
                  اتصل الآن
                </a>
                <Link href="/projects" className="border border-[#c9a84c]/40 text-[#c9a84c] hover:bg-[#c9a84c]/10 px-7 py-3.5 rounded-xl inline-flex items-center gap-2 transition-colors font-bold text-base" style={{fontFamily:'Cairo,sans-serif'}}>
                  مشاريعنا
                </Link>
              </div>
            </div>

            {/* شبكة الصور مع إطارات ذهبية */}
            <div className="fade-in-up grid grid-cols-2 gap-4">
              <GoldFrame className="rounded-2xl overflow-hidden">
                <img src="/manus-storage/palm-transplant_e04f8b1e.jpg" alt="نقل النخيل الاحترافي" className="w-full h-52 object-cover rounded-2xl" loading="lazy" />
              </GoldFrame>
              <GoldFrame className="rounded-2xl overflow-hidden mt-8">
                <img src="/manus-storage/villa-palms_9becb0e1.jpg" alt="نخيل الفلل" className="w-full h-52 object-cover rounded-2xl" loading="lazy" />
              </GoldFrame>
              <GoldFrame className="rounded-2xl overflow-hidden -mt-4 col-span-2">
                <img src="/manus-storage/palm-nursery_1b1f6210.jpg" alt="مشتل النخيل" className="w-full h-52 object-cover rounded-2xl" loading="lazy" />
              </GoldFrame>
            </div>
          </div>
        </div>
      </section>

      {/* ===== قسم أنواع النخيل ===== */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 text-[#1a3d2b]/3 pointer-events-none" style={{transform:'scaleX(-1)'}}>
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 fade-in-up">
            <span className="text-[#c9a84c] font-bold text-xs uppercase tracking-[0.3em]" style={{fontFamily:'Cairo,sans-serif'}}>تشكيلتنا الواسعة</span>
            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#1a3d2b] mt-3 mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
              أنواع النخيل المتوفرة
            </h2>
            <div className="flex items-center justify-center gap-3">
              <div className="h-px w-16 bg-gradient-to-l from-[#c9a84c] to-transparent" />
              <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
              <div className="h-px w-16 bg-gradient-to-r from-[#c9a84c] to-transparent" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {palmTypes.map((palm, i) => (
              <Link
                key={palm.href}
                href={palm.href}
                className="group relative overflow-hidden rounded-2xl fade-in-up"
                style={{ transitionDelay: `${i * 60}ms` }}
              >
                {/* صورة الخلفية */}
                <div className="h-56 overflow-hidden">
                  <img
                    src={palm.img}
                    alt={palm.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0d2418]/90 via-[#0d2418]/40 to-transparent" />
                </div>
                {/* المحتوى */}
                <div className="absolute inset-0 flex flex-col justify-end p-6">
                  {/* إطار ذهبي */}
                  <div className="absolute top-3 right-3 w-6 h-6 border-t border-r border-[#c9a84c]/50 group-hover:border-[#c9a84c] transition-colors" />
                  <div className="absolute top-3 left-3 w-6 h-6 border-t border-l border-[#c9a84c]/50 group-hover:border-[#c9a84c] transition-colors" />
                  <h3 className="text-xl font-extrabold text-white mb-1 group-hover:text-[#c9a84c] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
                    {palm.name}
                  </h3>
                  <p className="text-white/70 text-sm leading-relaxed">{palm.desc}</p>
                  <div className="flex items-center gap-2 text-[#c9a84c] text-sm font-bold mt-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200" style={{fontFamily:'Cairo,sans-serif'}}>
                    <span>اعرف المزيد</span>
                    <ArrowLeft className="w-4 h-4 rotate-180" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== قسم المناطق ===== */}
      <section className="py-24 bg-[#faf8f3] relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-64 h-64 text-[#1a3d2b]/4 pointer-events-none">
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="text-center mb-16 fade-in-up">
            <span className="text-[#c9a84c] font-bold text-xs uppercase tracking-[0.3em]" style={{fontFamily:'Cairo,sans-serif'}}>تغطية شاملة</span>
            <h2 className="text-3xl lg:text-5xl font-extrabold text-[#1a3d2b] mt-3 mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
              نخدم جميع مناطق المملكة
            </h2>
            <div className="flex items-center justify-center gap-3">
              <div className="h-px w-16 bg-gradient-to-l from-[#c9a84c] to-transparent" />
              <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
              <div className="h-px w-16 bg-gradient-to-r from-[#c9a84c] to-transparent" />
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
            {cities.map((city, i) => (
              <Link
                key={city.name}
                href={city.href}
                className="group relative bg-white border border-[#c9a84c]/20 rounded-xl p-4 text-center hover:bg-[#1a3d2b] hover:border-[#1a3d2b] transition-all duration-300 fade-in-up overflow-hidden"
                style={{ transitionDelay: `${i * 40}ms` }}
              >
                {/* إطار ذهبي صغير */}
                <div className="absolute top-1.5 right-1.5 w-3 h-3 border-t border-r border-[#c9a84c]/30 group-hover:border-[#c9a84c]/60 transition-colors" />
                <div className="absolute bottom-1.5 left-1.5 w-3 h-3 border-b border-l border-[#c9a84c]/30 group-hover:border-[#c9a84c]/60 transition-colors" />
                <MapPin className="w-5 h-5 text-[#c9a84c] mx-auto mb-2 group-hover:scale-110 transition-transform" />
                <div className="text-sm font-bold text-[#1a3d2b] group-hover:text-[#c9a84c] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
                  {city.name}
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ===== قسم نموذج عرض السعر ===== */}
      <section id="quote" className="py-24 section-dark relative overflow-hidden">
        <div className="absolute inset-0 palm-pattern opacity-8" />
        {/* زخرفة */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#c9a84c]/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#c9a84c]/50 to-transparent" />

        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-2xl mx-auto">
            <GoldFrame className="rounded-3xl">
              <div className="bg-white/8 backdrop-blur-sm border border-white/15 rounded-3xl p-8 lg:p-12">
                <QuoteForm
                  title="اطلب عرض سعر مجاني"
                  subtitle="أرسل تفاصيل مشروعك وسنتواصل معك فوراً"
                  dark={true}
                />
              </div>
            </GoldFrame>
          </div>
        </div>
      </section>

      {/* ===== قسم الأسئلة الشائعة ===== */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-56 h-56 text-[#1a3d2b]/3 pointer-events-none" style={{transform:'scaleX(-1)'}}>
          <PalmLeafDecor className="w-full h-full" />
        </div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto">
            <div className="text-center mb-16 fade-in-up">
              <span className="text-[#c9a84c] font-bold text-xs uppercase tracking-[0.3em]" style={{fontFamily:'Cairo,sans-serif'}}>أسئلة شائعة</span>
              <h2 className="text-3xl lg:text-5xl font-extrabold text-[#1a3d2b] mt-3 mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                الأسئلة الأكثر شيوعاً
              </h2>
              <div className="flex items-center justify-center gap-3">
                <div className="h-px w-16 bg-gradient-to-l from-[#c9a84c] to-transparent" />
                <div className="w-2 h-2 bg-[#c9a84c] rounded-full" />
                <div className="h-px w-16 bg-gradient-to-r from-[#c9a84c] to-transparent" />
              </div>
            </div>
            <div className="space-y-4">
              {faqs.map((faq, i) => (
                <div
                  key={i}
                  className="border border-[#c9a84c]/20 rounded-xl overflow-hidden fade-in-up hover:border-[#c9a84c]/40 transition-colors"
                  style={{ transitionDelay: `${i * 80}ms` }}
                >
                  <details className="group">
                    <summary className="flex items-center justify-between p-5 cursor-pointer bg-[#faf8f3] hover:bg-[#f0ece0] transition-colors">
                      <span className="font-bold text-[#1a3d2b]" style={{fontFamily:'Cairo,sans-serif'}}>{faq.q}</span>
                      <span className="w-7 h-7 rounded-full bg-[#c9a84c]/15 border border-[#c9a84c]/30 flex items-center justify-center text-[#c9a84c] font-bold group-open:rotate-45 transition-transform duration-200 shrink-0">+</span>
                    </summary>
                    <div className="p-5 text-gray-700 leading-relaxed border-t border-[#c9a84c]/10">
                      {faq.a}
                    </div>
                  </details>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== قسم CTA النهائي ===== */}
      <section className="py-20 bg-[#1a3d2b] relative overflow-hidden">
        <div className="absolute inset-0 palm-pattern opacity-10" />
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#c9a84c]/40 to-transparent" />
        <div className="container mx-auto px-4 relative z-10 text-center">
          <PalmLeafDecor className="w-24 h-12 text-[#c9a84c]/20 mx-auto mb-6" />
          <h2 className="text-3xl lg:text-4xl font-extrabold text-white mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
            هل تحتاج نخيلاً لمشروعك؟ تواصل معنا الآن
          </h2>
          <p className="text-white/70 mb-8 text-lg">
            نوفر أجود أنواع النخيل مع خدمات النقل والزراعة في جميع مناطق المملكة
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="tel:+966500000000" className="btn-gold px-8 py-4 rounded-xl text-base inline-flex items-center justify-center gap-2" style={{fontFamily:'Cairo,sans-serif'}}>
              <Phone className="w-5 h-5" />
              اتصل الآن
            </a>
            <a
              href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-whatsapp px-8 py-4 rounded-xl text-base inline-flex items-center justify-center gap-2"
              style={{fontFamily:'Cairo,sans-serif'}}
            >
              <MessageCircle className="w-5 h-5" />
              راسلنا على واتساب
            </a>
          </div>
        </div>
      </section>

    </div>
  );
}
