/**
 * QuoteForm - نموذج طلب عرض السعر
 * يظهر في جميع الصفحات
 */
import { useState } from "react";
import { Send, CheckCircle } from "lucide-react";

interface QuoteFormProps {
  title?: string;
  subtitle?: string;
  dark?: boolean;
}

export default function QuoteForm({
  title = "اطلب عرض سعر مجاني",
  subtitle = "تواصل معنا الآن وسنرد عليك خلال ساعات",
  dark = false,
}: QuoteFormProps) {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({
    name: "",
    phone: "",
    city: "",
    service: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // إرسال عبر واتساب
    const msg = `السلام عليكم،\nاسمي: ${form.name}\nرقم الجوال: ${form.phone}\nالمدينة: ${form.city}\nالخدمة المطلوبة: ${form.service}\nالتفاصيل: ${form.message}`;
    window.open(`https://wa.me/966500000000?text=${encodeURIComponent(msg)}`, "_blank");
    setSubmitted(true);
  };

  const bgClass = dark ? "bg-white/10 border-white/20 text-white placeholder:text-white/50" : "bg-white border-[#c9a84c]/30 text-[#1a3d2b] placeholder:text-gray-400";
  const labelClass = dark ? "text-white/80" : "text-[#1a3d2b]";

  if (submitted) {
    return (
      <div className="text-center py-12">
        <CheckCircle className="w-16 h-16 text-[#c9a84c] mx-auto mb-4" />
        <h3 className={`text-2xl font-bold mb-2 ${dark ? 'text-white' : 'text-[#1a3d2b]'}`} style={{fontFamily:'Cairo,sans-serif'}}>
          تم إرسال طلبك بنجاح!
        </h3>
        <p className={dark ? 'text-white/70' : 'text-gray-600'}>
          سيتم تحويلك إلى واتساب لإتمام التواصل. سنرد عليك في أقرب وقت.
        </p>
        <button
          onClick={() => setSubmitted(false)}
          className="mt-6 text-[#c9a84c] underline text-sm"
        >
          إرسال طلب آخر
        </button>
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-8">
        <h2 className={`text-2xl lg:text-3xl font-extrabold mb-2 ${dark ? 'text-white' : 'text-[#1a3d2b]'}`} style={{fontFamily:'Cairo,sans-serif'}}>
          {title}
        </h2>
        <div className="gold-accent-line mx-auto mb-3"></div>
        <p className={dark ? 'text-white/70' : 'text-gray-600'}>{subtitle}</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={`block text-sm font-semibold mb-1.5 ${labelClass}`} style={{fontFamily:'Cairo,sans-serif'}}>
              الاسم الكريم *
            </label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="أدخل اسمك"
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:border-[#c9a84c] transition-colors ${bgClass}`}
              style={{fontFamily:'Tajawal,sans-serif'}}
            />
          </div>
          <div>
            <label className={`block text-sm font-semibold mb-1.5 ${labelClass}`} style={{fontFamily:'Cairo,sans-serif'}}>
              رقم الجوال *
            </label>
            <input
              type="tel"
              required
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="05xxxxxxxx"
              dir="ltr"
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:border-[#c9a84c] transition-colors ${bgClass}`}
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className={`block text-sm font-semibold mb-1.5 ${labelClass}`} style={{fontFamily:'Cairo,sans-serif'}}>
              المدينة
            </label>
            <select
              value={form.city}
              onChange={(e) => setForm({ ...form, city: e.target.value })}
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:border-[#c9a84c] transition-colors ${bgClass}`}
              style={{fontFamily:'Tajawal,sans-serif'}}
            >
              <option value="">اختر مدينتك</option>
              {["الرياض","جدة","مكة المكرمة","المدينة المنورة","الدمام","الخبر","الأحساء","القصيم","حائل","تبوك","أبها","جازان","نجران"].map(c => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
          <div>
            <label className={`block text-sm font-semibold mb-1.5 ${labelClass}`} style={{fontFamily:'Cairo,sans-serif'}}>
              الخدمة المطلوبة
            </label>
            <select
              value={form.service}
              onChange={(e) => setForm({ ...form, service: e.target.value })}
              className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:border-[#c9a84c] transition-colors ${bgClass}`}
              style={{fontFamily:'Tajawal,sans-serif'}}
            >
              <option value="">اختر الخدمة</option>
              {["توريد نخيل","زراعة نخيل","نقل نخيل","شراء نخيل كبير","نخيل للفلل","نخيل للمشاريع الحكومية","تنسيق مواقع بالنخيل"].map(s => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className={`block text-sm font-semibold mb-1.5 ${labelClass}`} style={{fontFamily:'Cairo,sans-serif'}}>
            تفاصيل الطلب
          </label>
          <textarea
            value={form.message}
            onChange={(e) => setForm({ ...form, message: e.target.value })}
            placeholder="اذكر تفاصيل مشروعك وعدد النخيل المطلوب..."
            rows={4}
            className={`w-full px-4 py-3 rounded-xl border text-sm outline-none focus:border-[#c9a84c] transition-colors resize-none ${bgClass}`}
            style={{fontFamily:'Tajawal,sans-serif'}}
          />
        </div>

        <button
          type="submit"
          className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-[#c9a84c] to-[#e8c96b] text-[#1a3d2b] py-4 rounded-xl font-extrabold text-lg hover:shadow-xl hover:-translate-y-0.5 active:scale-95 transition-all duration-200"
          style={{fontFamily:'Cairo,sans-serif'}}
        >
          <Send className="w-5 h-5" />
          إرسال الطلب عبر واتساب
        </button>
      </form>
    </div>
  );
}
