/**
 * FloatingButtons - أزرار التواصل العائمة
 * واتساب + اتصال — دائمة الظهور في جميع الصفحات
 */
import { Phone, MessageCircle } from "lucide-react";

export default function FloatingButtons() {
  return (
    <div className="fixed bottom-6 left-6 z-50 flex flex-col gap-3">
      {/* زر واتساب */}
      <a
        href="https://wa.me/966500000000?text=السلام عليكم، أريد الاستفسار عن خدمات توريد النخيل"
        target="_blank"
        rel="noopener noreferrer"
        className="floating-btn bg-[#25D366] hover:bg-[#20bd5a] animate-pulse-gold"
        aria-label="تواصل عبر واتساب"
        title="راسلنا على واتساب"
      >
        <MessageCircle className="w-6 h-6 text-white" />
      </a>

      {/* زر الاتصال */}
      <a
        href="tel:+966500000000"
        className="floating-btn bg-[#c9a84c] hover:bg-[#e8c96b]"
        aria-label="اتصل بنا"
        title="اتصل بنا الآن"
      >
        <Phone className="w-6 h-6 text-[#1a3d2b]" />
      </a>
    </div>
  );
}
