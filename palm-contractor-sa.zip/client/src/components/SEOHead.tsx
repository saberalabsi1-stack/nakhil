/**
 * SEOHead - مكون SEO ديناميكي
 * يُحدّث document.title وmeta tags وSchema.org لكل صفحة
 */
import { useEffect } from "react";

interface SEOHeadProps {
  title: string;
  description: string;
  keywords?: string;
  canonical?: string;
  schema?: object | object[];
  ogImage?: string;
  noindex?: boolean;
}

const BASE_URL = "https://palm-contractor-sa.manus.space";
const DEFAULT_OG_IMAGE = `${BASE_URL}/og-image.jpg`;
const SITE_NAME = "مقاول توريد نخيل السعودية";

export default function SEOHead({
  title,
  description,
  keywords,
  canonical,
  schema,
  ogImage = DEFAULT_OG_IMAGE,
  noindex = false,
}: SEOHeadProps) {
  const fullTitle = title.includes(SITE_NAME)
    ? title
    : `${title} | ${SITE_NAME}`;

  const canonicalUrl = canonical
    ? `${BASE_URL}${canonical}`
    : BASE_URL;

  useEffect(() => {
    // Update title
    document.title = fullTitle;

    // Helper to set meta tag
    const setMeta = (selector: string, content: string) => {
      let el = document.querySelector(selector) as HTMLMetaElement | null;
      if (!el) {
        el = document.createElement("meta");
        const attr = selector.includes("[name=")
          ? "name"
          : selector.includes("[property=")
          ? "property"
          : "name";
        const val = selector.match(/["']([^"']+)["']/)?.[1] || "";
        el.setAttribute(attr, val);
        document.head.appendChild(el);
      }
      el.setAttribute("content", content);
    };

    // Basic meta
    setMeta('meta[name="description"]', description);
    if (keywords) setMeta('meta[name="keywords"]', keywords);
    setMeta('meta[name="robots"]', noindex ? "noindex,nofollow" : "index,follow,max-image-preview:large,max-snippet:-1,max-video-preview:-1");

    // Canonical
    let canonicalEl = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonicalEl) {
      canonicalEl = document.createElement("link");
      canonicalEl.setAttribute("rel", "canonical");
      document.head.appendChild(canonicalEl);
    }
    canonicalEl.setAttribute("href", canonicalUrl);

    // Open Graph
    setMeta('meta[property="og:title"]', fullTitle);
    setMeta('meta[property="og:description"]', description);
    setMeta('meta[property="og:url"]', canonicalUrl);
    setMeta('meta[property="og:image"]', ogImage);
    setMeta('meta[property="og:site_name"]', SITE_NAME);

    // Twitter
    setMeta('meta[name="twitter:title"]', fullTitle);
    setMeta('meta[name="twitter:description"]', description);
    setMeta('meta[name="twitter:image"]', ogImage);

    // Schema.org
    if (schema) {
      // Remove existing dynamic schemas
      document.querySelectorAll('script[data-dynamic-schema]').forEach(el => el.remove());

      const schemas = Array.isArray(schema) ? schema : [schema];
      schemas.forEach((s, i) => {
        const scriptEl = document.createElement("script");
        scriptEl.type = "application/ld+json";
        scriptEl.setAttribute("data-dynamic-schema", String(i));
        scriptEl.textContent = JSON.stringify(s);
        document.head.appendChild(scriptEl);
      });
    }

    return () => {
      // Cleanup dynamic schemas on unmount
      document.querySelectorAll('script[data-dynamic-schema]').forEach(el => el.remove());
    };
  }, [fullTitle, description, keywords, canonicalUrl, ogImage, noindex, schema]);

  return null;
}

// ============ Schema Builders ============

export function buildServiceSchema(name: string, description: string, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    "name": name,
    "description": description,
    "url": `${BASE_URL}${url}`,
    "provider": {
      "@type": "LocalBusiness",
      "@id": `${BASE_URL}/`,
      "name": SITE_NAME,
      "telephone": "+966500000000",
      "areaServed": { "@type": "Country", "name": "Saudi Arabia" }
    },
    "areaServed": { "@type": "Country", "name": "Saudi Arabia" }
  };
}

export function buildCitySchema(cityName: string, citySlug: string) {
  return {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": `${BASE_URL}/cities/${citySlug}`,
    "name": `مقاول توريد نخيل ${cityName}`,
    "description": `خدمات توريد وزراعة ونقل النخيل في ${cityName} - مقاول توريد نخيل السعودية`,
    "url": `${BASE_URL}/cities/${citySlug}`,
    "telephone": "+966500000000",
    "areaServed": {
      "@type": "City",
      "name": cityName,
      "containedInPlace": { "@type": "Country", "name": "Saudi Arabia" }
    },
    "parentOrganization": {
      "@type": "LocalBusiness",
      "@id": `${BASE_URL}/`,
      "name": SITE_NAME
    }
  };
}

export function buildFAQSchema(faqs: { q: string; a: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": faqs.map(faq => ({
      "@type": "Question",
      "name": faq.q,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.a
      }
    }))
  };
}

export function buildBreadcrumbSchema(items: { name: string; url: string }[]) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": items.map((item, i) => ({
      "@type": "ListItem",
      "position": i + 1,
      "name": item.name,
      "item": `${BASE_URL}${item.url}`
    }))
  };
}
