/**
 * ServicesListPage - قائمة جميع الخدمات
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Truck, Sprout, TreePine, Building2, Home as HomeIcon, Landmark, Palette, ArrowLeft } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const services = [
  { icon: Truck, title: "توريد النخيل", desc: "نوفر أجود أنواع النخيل من جميع أنحاء المملكة بأسعار تنافسية مع ضمان الجودة والحيوية", href: "/services/supply" },
  { icon: Sprout, title: "زراعة النخيل", desc: "فريق متخصص في زراعة النخيل بالطرق الصحيحة لضمان نمو صحي وطويل الأمد", href: "/services/planting" },
  { icon: Truck, title: "نقل النخيل", desc: "نقل آمن للنخيل بمعدات متخصصة وسيارات مجهزة للحفاظ على سلامة النخلة", href: "/services/transport" },
  { icon: TreePine, title: "بيع النخيل الكبير", desc: "نخيل كبير ومعمّر بأحجام مختلفة مناسب للمشاريع الكبرى والمداخل الفاخرة", href: "/services/large-palms" },
  { icon: HomeIcon, title: "نخيل للفلل والقصور", desc: "حلول متكاملة لتزيين الفلل والقصور والاستراحات بأجمل أنواع النخيل", href: "/services/villas" },
  { icon: Landmark, title: "نخيل للمشاريع الحكومية", desc: "خبرة واسعة في تنفيذ مشاريع التشجير الحكومية والبنية التحتية", href: "/services/government" },
  { icon: Palette, title: "تنسيق المواقع بالنخيل", desc: "تصميم وتنسيق المواقع والحدائق بالنخيل لإبراز الجمال الطبيعي", href: "/services/landscaping" },
];

export default function ServicesListPage() {
  useScrollReveal();
  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      {/* Hero */}
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">خدماتنا</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>خدماتنا المتكاملة</h1>
          <p className="text-white/70 mt-2">كل ما تحتاجه في عالم النخيل تحت سقف واحد</p>
        </div>
      </section>

      <section className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {services.map((service, i) => (
              <Link key={service.href} href={service.href} className="service-card p-8 group fade-in-up" style={{ transitionDelay: `${i * 60}ms` }}>
                <div className="w-16 h-16 bg-[#1a3d2b]/10 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-[#1a3d2b] group-hover:scale-110 transition-all duration-300">
                  <service.icon className="w-8 h-8 text-[#1a3d2b] group-hover:text-[#c9a84c] transition-colors" />
                </div>
                <h2 className="text-xl font-bold text-[#1a3d2b] mb-3" style={{fontFamily:'Cairo,sans-serif'}}>{service.title}</h2>
                <p className="text-gray-600 leading-relaxed mb-5">{service.desc}</p>
                <div className="flex items-center gap-2 text-[#c9a84c] font-semibold group-hover:gap-3 transition-all" style={{fontFamily:'Cairo,sans-serif'}}>
                  <span>اعرف المزيد</span>
                  <ArrowLeft className="w-4 h-4 rotate-180" />
                </div>
              </Link>
            ))}
          </div>
          <div className="max-w-2xl mx-auto bg-[#1a3d2b] rounded-3xl p-8 lg:p-12">
            <QuoteForm title="اطلب عرض سعر مجاني" subtitle="نرد عليك خلال ساعات" dark={true} />
          </div>
        </div>
      </section>
    </div>
  );
}
