import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Header from "./components/Header";
import Footer from "./components/Footer";
import FloatingButtons from "./components/FloatingButtons";

// Pages
import Home from "./pages/Home";
import ContactPage from "./pages/ContactPage";
import ProjectsPage from "./pages/ProjectsPage";
import BlogPage from "./pages/BlogPage";
import ServicesListPage from "./pages/ServicesListPage";
import CitiesListPage from "./pages/CitiesListPage";
import PalmTypesListPage from "./pages/PalmTypesListPage";

// Service Pages
import SupplyPage from "./pages/services/SupplyPage";
import PlantingPage from "./pages/services/PlantingPage";
import TransportPage from "./pages/services/TransportPage";
import LargePalmsPage from "./pages/services/LargePalmsPage";
import VillasPage from "./pages/services/VillasPage";
import GovernmentPage from "./pages/services/GovernmentPage";
import LandscapingPage from "./pages/services/LandscapingPage";

// City Pages
import RiyadhPage from "./pages/cities/RiyadhPage";
import { JeddahPage, MeccaPage, MadinahPage, DammamPage, KhobarPage, AhsaPage, QassimPage, HailPage, TabukPage, AbhaPage, JazanPage } from "./pages/cities/OtherCities";

// Palm Type Pages
import { SukkariPage, KhallasPage, BarhiPage, MedjoolPage, WashingtoniaPage, CanaryPage } from "./pages/palm-types/PalmTypes";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col" dir="rtl">
      <Header />
      <main className="flex-1 pt-[4.5rem] lg:pt-[5.5rem]">
        {children}
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      {/* الصفحة الرئيسية */}
      <Route path="/" component={Home} />

      {/* صفحات الخدمات */}
      <Route path="/services" component={ServicesListPage} />
      <Route path="/services/supply" component={SupplyPage} />
      <Route path="/services/planting" component={PlantingPage} />
      <Route path="/services/transport" component={TransportPage} />
      <Route path="/services/large-palms" component={LargePalmsPage} />
      <Route path="/services/villas" component={VillasPage} />
      <Route path="/services/government" component={GovernmentPage} />
      <Route path="/services/landscaping" component={LandscapingPage} />

      {/* صفحات المدن */}
      <Route path="/cities" component={CitiesListPage} />
      <Route path="/cities/riyadh" component={RiyadhPage} />
      <Route path="/cities/jeddah" component={JeddahPage} />
      <Route path="/cities/mecca" component={MeccaPage} />
      <Route path="/cities/madinah" component={MadinahPage} />
      <Route path="/cities/dammam" component={DammamPage} />
      <Route path="/cities/khobar" component={KhobarPage} />
      <Route path="/cities/ahsa" component={AhsaPage} />
      <Route path="/cities/qassim" component={QassimPage} />
      <Route path="/cities/hail" component={HailPage} />
      <Route path="/cities/tabuk" component={TabukPage} />
      <Route path="/cities/abha" component={AbhaPage} />
      <Route path="/cities/jazan" component={JazanPage} />

      {/* صفحات أنواع النخيل */}
      <Route path="/palm-types" component={PalmTypesListPage} />
      <Route path="/palm-types/sukkari" component={SukkariPage} />
      <Route path="/palm-types/khallas" component={KhallasPage} />
      <Route path="/palm-types/barhi" component={BarhiPage} />
      <Route path="/palm-types/medjool" component={MedjoolPage} />
      <Route path="/palm-types/washingtonia" component={WashingtoniaPage} />
      <Route path="/palm-types/canary" component={CanaryPage} />

      {/* صفحات أخرى */}
      <Route path="/projects" component={ProjectsPage} />
      <Route path="/blog" component={BlogPage} />
      <Route path="/contact" component={ContactPage} />

      {/* 404 */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Layout>
            <Router />
          </Layout>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
