/**
 * PalmTypePage - صفحة نوع نخيل عامة
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle, CheckCircle } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";
import SEOHead, { buildFAQSchema, buildBreadcrumbSchema } from "@/components/SEOHead";

interface PalmTypePageProps {
  name: string;
  arabicName: string;
  scientificName: string;
  description: string;
  characteristics: string[];
  uses: string[];
  plantingTips: string[];
  content: string[];
  faqs: { q: string; a: string }[];
  image: string;
  slug?: string;
}

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

export default function PalmTypePage({ name, arabicName, scientificName, description, characteristics, uses, plantingTips, content, faqs, image, slug }: PalmTypePageProps) {
  useScrollReveal();

  const schemas = [
    buildFAQSchema(faqs),
    buildBreadcrumbSchema([
      { name: 'الرئيسية', url: '/' },
      { name: 'أنواع النخيل', url: '/palm-types' },
      { name: arabicName, url: slug ? `/palm-types/${slug}` : '/palm-types' },
    ]),
  ];

  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <SEOHead
        title={`نخيل ${arabicName} للبيع والتوريد في السعودية`}
        description={`${description.slice(0, 155)}...`}
        keywords={`نخيل ${arabicName}, ${arabicName} للبيع, توريد نخيل ${arabicName}, سعر نخيل ${arabicName}`}
        canonical={slug ? `/palm-types/${slug}` : '/palm-types'}
        schema={schemas}
      />
      <section className="relative h-72 lg:h-96 flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img src={image} alt={arabicName} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b]/60 to-[#0d2418]/90" />
        </div>
        <div className="relative z-10 container mx-auto px-4 pb-12 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <Link href="/palm-types" className="hover:text-[#c9a84c]">أنواع النخيل</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">{arabicName}</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>{arabicName}</h1>
          <p className="text-white/70 mt-1 text-sm italic">{scientificName}</p>
        </div>
      </section>

      <div className="bg-[#c9a84c] py-4">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[#1a3d2b] font-bold" style={{fontFamily:'Cairo,sans-serif'}}>هل تريد {arabicName}؟ تواصل معنا الآن</p>
          <div className="flex gap-3">
            <a href="tel:+966500000000" className="flex items-center gap-2 bg-[#1a3d2b] text-white px-5 py-2 rounded-lg font-bold text-sm" style={{fontFamily:'Cairo,sans-serif'}}>
              <Phone className="w-4 h-4" /> اتصل الآن
            </a>
            <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-[#25D366] text-white px-5 py-2 rounded-lg font-bold text-sm" style={{fontFamily:'Cairo,sans-serif'}}>
              <MessageCircle className="w-4 h-4" /> واتساب
            </a>
          </div>
        </div>
      </div>

      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2 space-y-8">
              <div className="fade-in-up">
                <p className="text-gray-700 leading-relaxed text-lg">{description}</p>
              </div>

              <div className="fade-in-up grid md:grid-cols-3 gap-6">
                <div className="bg-[#faf8f3] rounded-2xl p-5">
                  <h3 className="font-bold text-[#1a3d2b] mb-3" style={{fontFamily:'Cairo,sans-serif'}}>المميزات</h3>
                  <ul className="space-y-2">
                    {characteristics.map((c, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#c9a84c] shrink-0 mt-0.5" />
                        {c}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-[#faf8f3] rounded-2xl p-5">
                  <h3 className="font-bold text-[#1a3d2b] mb-3" style={{fontFamily:'Cairo,sans-serif'}}>الاستخدامات</h3>
                  <ul className="space-y-2">
                    {uses.map((u, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#c9a84c] shrink-0 mt-0.5" />
                        {u}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="bg-[#faf8f3] rounded-2xl p-5">
                  <h3 className="font-bold text-[#1a3d2b] mb-3" style={{fontFamily:'Cairo,sans-serif'}}>نصائح الزراعة</h3>
                  <ul className="space-y-2">
                    {plantingTips.map((t, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                        <CheckCircle className="w-4 h-4 text-[#c9a84c] shrink-0 mt-0.5" />
                        {t}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {content.map((para, i) => (
                <div key={i} className="fade-in-up">
                  <p className="text-gray-700 leading-relaxed">{para}</p>
                </div>
              ))}

              <div className="fade-in-up">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>أسئلة شائعة</h2>
                <div className="gold-accent-line mb-6"></div>
                <div className="space-y-3">
                  {faqs.map((faq, i) => (
                    <div key={i} className="border border-[#c9a84c]/20 rounded-xl overflow-hidden">
                      <details className="group">
                        <summary className="flex items-center justify-between p-4 cursor-pointer bg-[#faf8f3] hover:bg-[#f0ece0] transition-colors">
                          <span className="font-bold text-[#1a3d2b] text-sm" style={{fontFamily:'Cairo,sans-serif'}}>{faq.q}</span>
                          <span className="text-[#c9a84c] text-xl font-bold group-open:rotate-45 transition-transform">+</span>
                        </summary>
                        <div className="p-4 text-gray-700 text-sm leading-relaxed border-t border-[#c9a84c]/10">{faq.a}</div>
                      </details>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-[#1a3d2b] rounded-2xl p-6 sticky top-24">
                <QuoteForm title={`اطلب ${arabicName}`} subtitle="نرد خلال ساعات" dark={true} />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
