/**
 * ProjectsPage - صفحة المشاريع
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const projects = [
  { title: "فلة فاخرة — حي النرجس، الرياض", type: "فلة خاصة", desc: "تنسيق حديقة فلة فاخرة بـ 15 نخلة سكري وخلاص بأحجام مختلفة مع تصميم إضاءة ليلية احترافية.", img: "/manus-storage/villa-palms_9becb0e1.jpg", tag: "فلل خاصة" },
  { title: "استراحة ملكية — القصيم", type: "استراحة", desc: "توريد وزراعة 50 نخلة واشنطونيا لتزيين مدخل وحديقة استراحة كبرى في القصيم.", img: "/manus-storage/palm-nursery_1b1f6210.jpg", tag: "استراحات" },
  { title: "مزرعة نخيل — الأحساء", type: "مزرعة", desc: "توريد وزراعة 200 نخلة سكري وبرحي في مزرعة متخصصة بالأحساء مع نظام ري آلي متكامل.", img: "/manus-storage/hero-palms_f04092c0.jpg", tag: "مزارع" },
  { title: "منتجع سياحي — أبها", type: "منتجع", desc: "تنسيق حدائق منتجع سياحي في أبها بـ 80 نخلة كناري وواشنطونيا مع تصميم استوائي فاخر.", img: "/manus-storage/palm-transplant_e04f8b1e.jpg", tag: "منتجعات" },
  { title: "مشروع تشجير طريق — الرياض", type: "حكومي", desc: "تنفيذ مشروع تشجير طريق رئيسي في الرياض بـ 500 نخلة واشنطونيا لصالح أمانة الرياض.", img: "/manus-storage/hero-palms_f04092c0.jpg", tag: "مشاريع حكومية" },
  { title: "مجمع سكني — جدة", type: "تجاري", desc: "توريد وزراعة 120 نخلة لتزيين مداخل وحدائق مجمع سكني فاخر في جدة.", img: "/manus-storage/villa-palms_9becb0e1.jpg", tag: "مجمعات سكنية" },
];

const tags = ["الكل", "فلل خاصة", "استراحات", "مزارع", "منتجعات", "مشاريع حكومية", "مجمعات سكنية"];

export default function ProjectsPage() {
  useScrollReveal();
  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">مشاريعنا</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>مشاريعنا المنجزة</h1>
          <p className="text-white/70 mt-2">أكثر من 500 مشروع ناجح في جميع مناطق المملكة</p>
        </div>
      </section>

      <section className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
            {projects.map((project, i) => (
              <div key={i} className="service-card overflow-hidden fade-in-up" style={{ transitionDelay: `${i * 80}ms` }}>
                <div className="relative h-52 overflow-hidden">
                  <img src={project.img} alt={project.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" loading="lazy" />
                  <div className="absolute top-4 right-4 bg-[#c9a84c] text-[#1a3d2b] text-xs font-bold px-3 py-1 rounded-full" style={{fontFamily:'Cairo,sans-serif'}}>
                    {project.tag}
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-[#1a3d2b] mb-2" style={{fontFamily:'Cairo,sans-serif'}}>{project.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{project.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mb-12">
            <div className="bg-[#1a3d2b] text-white rounded-2xl p-8 max-w-2xl mx-auto">
              <h2 className="text-2xl font-extrabold mb-3" style={{fontFamily:'Cairo,sans-serif'}}>هل تريد مشروعاً مشابهاً؟</h2>
              <p className="text-white/70 mb-6">تواصل معنا الآن للحصول على استشارة مجانية وعرض سعر لمشروعك</p>
              <div className="flex gap-4 justify-center">
                <a href="tel:+966500000000" className="flex items-center gap-2 bg-[#c9a84c] text-[#1a3d2b] px-6 py-3 rounded-xl font-bold hover:bg-[#e8c96b] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
                  <Phone className="w-4 h-4" /> اتصل الآن
                </a>
                <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-[#25D366] text-white px-6 py-3 rounded-xl font-bold hover:bg-[#20bd5a] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
                  <MessageCircle className="w-4 h-4" /> واتساب
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
