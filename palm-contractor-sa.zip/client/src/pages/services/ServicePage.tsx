/**
 * ServicePage - صفحة خدمة عامة
 * تُستخدم لجميع صفحات الخدمات السبع
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle, CheckCircle, ArrowLeft } from "lucide-react";
import QuoteForm from "@/components/QuoteForm";
import SEOHead, { buildServiceSchema, buildFAQSchema, buildBreadcrumbSchema } from "@/components/SEOHead";

interface FAQ {
  q: string;
  a: string;
}

interface ServicePageProps {
  title: string;
  subtitle: string;
  description: string;
  heroImage: string;
  features: string[];
  benefits: string[];
  content: string[];
  faqs: FAQ[];
  relatedServices: { title: string; href: string }[];
  metaTitle?: string;
  metaDesc?: string;
  pageUrl?: string;
  keywords?: string;
}

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1, rootMargin: "0px 0px -50px 0px" }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

export default function ServicePage({
  title, subtitle, description, heroImage, features, benefits, content, faqs, relatedServices,
  metaTitle, metaDesc, pageUrl, keywords
}: ServicePageProps) {
  useScrollReveal();

  const seoTitle = metaTitle || `${title} في السعودية | مقاول توريد نخيل السعودية`;
  const seoDesc = metaDesc || `${description.slice(0, 155)}...`;
  const schemas = [
    buildServiceSchema(title, seoDesc, pageUrl || '/services'),
    buildFAQSchema(faqs),
    buildBreadcrumbSchema([
      { name: 'الرئيسية', url: '/' },
      { name: 'الخدمات', url: '/services' },
      { name: title, url: pageUrl || '/services' },
    ]),
  ];

  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <SEOHead
        title={seoTitle}
        description={seoDesc}
        keywords={keywords}
        canonical={pageUrl}
        schema={schemas}
      />
      {/* Hero */}
      <section className="relative h-72 lg:h-96 flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroImage} alt={title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b]/60 to-[#0d2418]/90" />
        </div>
        <div className="relative z-10 container mx-auto px-4 pb-12 pt-24">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c] transition-colors">الرئيسية</Link>
            <span>/</span>
            <Link href="/services" className="hover:text-[#c9a84c] transition-colors">الخدمات</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">{title}</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>{title}</h1>
          <p className="text-white/80 mt-2 text-lg">{subtitle}</p>
        </div>
      </section>

      {/* CTA شريط */}
      <div className="bg-[#c9a84c] py-4">
        <div className="container mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-[#1a3d2b] font-bold" style={{fontFamily:'Cairo,sans-serif'}}>
            هل تحتاج {title}؟ تواصل معنا الآن للحصول على عرض سعر مجاني
          </p>
          <div className="flex gap-3">
            <a href="tel:+966500000000" className="flex items-center gap-2 bg-[#1a3d2b] text-white px-5 py-2 rounded-lg font-bold text-sm hover:bg-[#2d6a4f] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
              <Phone className="w-4 h-4" /> اتصل الآن
            </a>
            <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-[#25D366] text-white px-5 py-2 rounded-lg font-bold text-sm hover:bg-[#20bd5a] transition-colors" style={{fontFamily:'Cairo,sans-serif'}}>
              <MessageCircle className="w-4 h-4" /> واتساب
            </a>
          </div>
        </div>
      </div>

      {/* المحتوى الرئيسي */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* المحتوى */}
            <div className="lg:col-span-2 space-y-8">
              <div className="fade-in-up">
                <p className="text-gray-700 leading-relaxed text-lg">{description}</p>
              </div>

              {/* المميزات */}
              <div className="fade-in-up">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                  مميزات خدمة {title}
                </h2>
                <div className="gold-accent-line mb-6"></div>
                <div className="grid sm:grid-cols-2 gap-3">
                  {features.map((f, i) => (
                    <div key={i} className="flex items-start gap-3 bg-[#faf8f3] rounded-xl p-4">
                      <CheckCircle className="w-5 h-5 text-[#c9a84c] shrink-0 mt-0.5" />
                      <span className="text-gray-700 text-sm">{f}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* المحتوى التفصيلي */}
              {content.map((para, i) => (
                <div key={i} className="fade-in-up prose prose-lg max-w-none">
                  <p className="text-gray-700 leading-relaxed">{para}</p>
                </div>
              ))}

              {/* الفوائد */}
              <div className="fade-in-up bg-[#1a3d2b] rounded-2xl p-8">
                <h2 className="text-2xl font-extrabold text-white mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                  لماذا تختار خدمتنا؟
                </h2>
                <div className="space-y-3">
                  {benefits.map((b, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-[#c9a84c] rounded-full flex items-center justify-center text-[#1a3d2b] font-bold text-xs shrink-0 mt-0.5">
                        {i + 1}
                      </div>
                      <span className="text-white/85">{b}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* الأسئلة الشائعة */}
              <div className="fade-in-up">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>
                  أسئلة شائعة حول {title}
                </h2>
                <div className="gold-accent-line mb-6"></div>
                <div className="space-y-3">
                  {faqs.map((faq, i) => (
                    <div key={i} className="border border-[#c9a84c]/20 rounded-xl overflow-hidden">
                      <details className="group">
                        <summary className="flex items-center justify-between p-4 cursor-pointer bg-[#faf8f3] hover:bg-[#f0ece0] transition-colors">
                          <span className="font-bold text-[#1a3d2b] text-sm" style={{fontFamily:'Cairo,sans-serif'}}>{faq.q}</span>
                          <span className="text-[#c9a84c] text-xl font-bold group-open:rotate-45 transition-transform">+</span>
                        </summary>
                        <div className="p-4 text-gray-700 text-sm leading-relaxed border-t border-[#c9a84c]/10">
                          {faq.a}
                        </div>
                      </details>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* الشريط الجانبي */}
            <div className="space-y-6">
              {/* نموذج عرض السعر */}
              <div className="bg-[#1a3d2b] rounded-2xl p-6 sticky top-24">
                <QuoteForm
                  title="اطلب عرض سعر"
                  subtitle="نرد خلال ساعات"
                  dark={true}
                />
              </div>

              {/* خدمات أخرى */}
              <div className="bg-[#faf8f3] rounded-2xl p-6">
                <h3 className="text-lg font-bold text-[#1a3d2b] mb-4" style={{fontFamily:'Cairo,sans-serif'}}>خدمات أخرى</h3>
                <div className="space-y-2">
                  {relatedServices.map((s) => (
                    <Link key={s.href} href={s.href} className="flex items-center justify-between p-3 bg-white rounded-xl hover:bg-[#1a3d2b] hover:text-white group transition-all duration-200">
                      <span className="text-sm font-semibold text-[#1a3d2b] group-hover:text-white" style={{fontFamily:'Cairo,sans-serif'}}>{s.title}</span>
                      <ArrowLeft className="w-4 h-4 text-[#c9a84c] rotate-180" />
                    </Link>
                  ))}
                </div>
              </div>

              {/* معلومات التواصل */}
              <div className="bg-[#c9a84c] rounded-2xl p-6 text-[#1a3d2b]">
                <h3 className="text-lg font-bold mb-3" style={{fontFamily:'Cairo,sans-serif'}}>تواصل مباشر</h3>
                <a href="tel:+966500000000" className="flex items-center gap-2 font-bold mb-3 hover:underline">
                  <Phone className="w-5 h-5" />
                  <span dir="ltr">+966 50 000 0000</span>
                </a>
                <a
                  href="https://wa.me/966500000000"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-[#25D366] text-white py-3 rounded-xl font-bold hover:bg-[#20bd5a] transition-colors w-full"
                  style={{fontFamily:'Cairo,sans-serif'}}
                >
                  <MessageCircle className="w-5 h-5" />
                  راسلنا على واتساب
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
