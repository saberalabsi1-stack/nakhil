/**
 * PalmTypesListPage - صفحة فهرس أنواع النخيل
 */
import { useEffect } from "react";
import { Link } from "wouter";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const palmTypes = [
  { name: "نخيل سكري", href: "/palm-types/sukkari", img: "/manus-storage/palm-nursery_1b1f6210.jpg", desc: "من أشهر وأجود أنواع النخيل السعودية، يتميز بتمره الحلو ومظهره الجميل" },
  { name: "نخيل خلاص", href: "/palm-types/khallas", img: "/manus-storage/hero-palms_f04092c0.jpg", desc: "ملك النخيل السعودي، يتميز بتمره الذهبي الفاخر ومظهره الملكي" },
  { name: "نخيل برحي", href: "/palm-types/barhi", img: "/manus-storage/villa-palms_9becb0e1.jpg", desc: "نخيل متوسط الحجم بتمر ذهبي جميل، مناسب للحدائق والمداخل" },
  { name: "نخيل مجدول", href: "/palm-types/medjool", img: "/manus-storage/palm-transplant_e04f8b1e.jpg", desc: "ملك النخيل عالمياً، يتميز بتمره الكبير الفاخر وجذعه المميز" },
  { name: "نخيل واشنطونيا", href: "/palm-types/washingtonia", img: "/manus-storage/hero-palms_f04092c0.jpg", desc: "نخيل زينة طويل وأنيق، مثالي لتزيين الشوارع والمداخل الكبرى" },
  { name: "نخيل كناري", href: "/palm-types/canary", img: "/manus-storage/villa-palms_9becb0e1.jpg", desc: "نخيل زينة فاخر بسعف كثيف، يضفي طابعاً استوائياً راقياً" },
];

export default function PalmTypesListPage() {
  useScrollReveal();
  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">أنواع النخيل</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>أنواع النخيل</h1>
          <p className="text-white/70 mt-2">تشكيلة واسعة من أجود أنواع النخيل السعودي والمستورد</p>
        </div>
      </section>

      <section className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {palmTypes.map((palm, i) => (
              <Link
                key={palm.href}
                href={palm.href}
                className="service-card overflow-hidden group fade-in-up"
                style={{ transitionDelay: `${i * 70}ms` }}
              >
                <div className="relative h-48 overflow-hidden">
                  <img src={palm.img} alt={palm.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1a3d2b]/60 to-transparent" />
                  <h2 className="absolute bottom-4 right-4 text-white font-extrabold text-xl" style={{fontFamily:'Cairo,sans-serif'}}>{palm.name}</h2>
                </div>
                <div className="p-5">
                  <p className="text-gray-600 text-sm leading-relaxed">{palm.desc}</p>
                  <div className="mt-4 text-[#c9a84c] font-semibold text-sm" style={{fontFamily:'Cairo,sans-serif'}}>اعرف المزيد ←</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
