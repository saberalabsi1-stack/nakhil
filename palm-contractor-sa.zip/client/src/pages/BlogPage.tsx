/**
 * BlogPage - صفحة المدونة
 */
import { useEffect } from "react";
import { Link } from "wouter";
import { ArrowLeft, Clock } from "lucide-react";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

const articles = [
  { slug: "palm-types-saudi", title: "أفضل أنواع النخيل للزراعة في السعودية", excerpt: "دليل شامل لأجود أنواع النخيل المناسبة للمناخ السعودي، من السكري والخلاص إلى الواشنطونيا والكناري، مع نصائح الزراعة والعناية.", img: "/manus-storage/palm-nursery_1b1f6210.jpg", date: "15 يناير 2025", readTime: "5 دقائق", category: "أنواع النخيل", keywords: "أنواع النخيل في السعودية" },
  { slug: "palm-transplant-guide", title: "كيفية نقل النخيل بأمان — دليل خطوة بخطوة", excerpt: "تعرف على الطريقة الصحيحة لنقل النخيل من موقع لآخر مع ضمان نجاح التأقلم والنمو السليم بعد النقل.", img: "/manus-storage/palm-transplant_e04f8b1e.jpg", date: "10 يناير 2025", readTime: "7 دقائق", category: "نقل النخيل", keywords: "كيفية نقل النخيل" },
  { slug: "villa-palm-guide", title: "أفضل أنواع النخيل للفلل السعودية", excerpt: "اختيار النخيل المناسب لفلتك يعتمد على عدة عوامل. تعرف على أفضل الأنواع وكيفية توظيفها لإبراز جمال فلتك.", img: "/manus-storage/villa-palms_9becb0e1.jpg", date: "5 يناير 2025", readTime: "6 دقائق", category: "نخيل الفلل", keywords: "أفضل أنواع النخيل للفلل" },
  { slug: "palm-planting-cost", title: "تكلفة زراعة النخيل في السعودية 2025", excerpt: "دليل شامل لتكاليف توريد وزراعة ونقل النخيل في المملكة العربية السعودية مع نصائح للحصول على أفضل الأسعار.", img: "/manus-storage/hero-palms_f04092c0.jpg", date: "1 يناير 2025", readTime: "8 دقائق", category: "أسعار النخيل", keywords: "تكلفة زراعة النخيل" },
  { slug: "large-palm-buy", title: "كيف تشتري نخيل كبير بأفضل سعر؟", excerpt: "نصائح ذهبية لشراء النخيل الكبير والمعمّر بأفضل جودة وسعر، وكيف تتجنب الأخطاء الشائعة عند الشراء.", img: "/manus-storage/palm-nursery_1b1f6210.jpg", date: "25 ديسمبر 2024", readTime: "5 دقائق", category: "شراء النخيل", keywords: "شراء نخيل كبير" },
  { slug: "palm-contractor-riyadh", title: "كيف تختار مقاول نخيل موثوق في الرياض؟", excerpt: "معايير اختيار مقاول النخيل المناسب في الرياض وما يجب الانتباه إليه قبل التعاقد لضمان نتائج مثالية.", img: "/manus-storage/hero-palms_f04092c0.jpg", date: "20 ديسمبر 2024", readTime: "6 دقائق", category: "نصائح", keywords: "مقاول نخيل بالرياض" },
];

export default function BlogPage() {
  useScrollReveal();
  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">المدونة</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>مدونة النخيل</h1>
          <p className="text-white/70 mt-2">مقالات ونصائح متخصصة في عالم النخيل السعودي</p>
        </div>
      </section>

      <section className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {articles.map((article, i) => (
              <article key={article.slug} className="service-card overflow-hidden fade-in-up" style={{ transitionDelay: `${i * 80}ms` }}>
                <div className="relative h-48 overflow-hidden">
                  <img src={article.img} alt={article.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" loading="lazy" />
                  <div className="absolute top-3 right-3 bg-[#1a3d2b] text-white text-xs font-bold px-3 py-1 rounded-full" style={{fontFamily:'Cairo,sans-serif'}}>
                    {article.category}
                  </div>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-3 text-gray-400 text-xs mb-3">
                    <span>{article.date}</span>
                    <span>•</span>
                    <div className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{article.readTime}</span>
                    </div>
                  </div>
                  <h2 className="font-bold text-[#1a3d2b] mb-2 leading-snug" style={{fontFamily:'Cairo,sans-serif'}}>{article.title}</h2>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4 line-clamp-3">{article.excerpt}</p>
                  <div className="flex items-center gap-2 text-[#c9a84c] font-semibold text-sm hover:gap-3 transition-all cursor-pointer" style={{fontFamily:'Cairo,sans-serif'}}>
                    <span>اقرأ المزيد</span>
                    <ArrowLeft className="w-4 h-4 rotate-180" />
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
