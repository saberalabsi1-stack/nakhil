/**
 * ContactPage - صفحة التواصل
 */
import { useEffect, useState } from "react";
import { Link } from "wouter";
import { Phone, MessageCircle, MapPin, Clock, Mail } from "lucide-react";
import { toast } from "sonner";

function useScrollReveal() {
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("visible")),
      { threshold: 0.1 }
    );
    document.querySelectorAll(".fade-in-up").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
}

export default function ContactPage() {
  useScrollReveal();
  const [form, setForm] = useState({ name: "", phone: "", city: "", service: "", message: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) {
      toast.error("يرجى تعبئة الاسم ورقم الجوال على الأقل");
      return;
    }
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast.success("تم إرسال رسالتك بنجاح! سنتواصل معك قريباً");
      setForm({ name: "", phone: "", city: "", service: "", message: "" });
    }, 1500);
  };

  return (
    <div className="min-h-screen" style={{fontFamily:'Tajawal,sans-serif'}}>
      <section className="relative h-64 flex items-end overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-[#1a3d2b] to-[#0d2418]" />
        <div className="absolute inset-0 palm-pattern opacity-20" />
        <div className="relative z-10 container mx-auto px-4 pb-10 pt-24">
          <nav className="flex items-center gap-2 text-white/60 text-sm mb-3" style={{fontFamily:'Cairo,sans-serif'}}>
            <Link href="/" className="hover:text-[#c9a84c]">الرئيسية</Link>
            <span>/</span>
            <span className="text-[#c9a84c]">تواصل معنا</span>
          </nav>
          <h1 className="text-3xl lg:text-5xl font-extrabold text-white" style={{fontFamily:'Cairo,sans-serif'}}>تواصل معنا</h1>
          <p className="text-white/70 mt-2">نرد على استفساراتك خلال ساعات — متاحون 7 أيام في الأسبوع</p>
        </div>
      </section>

      <section id="quote" className="py-16 bg-[#faf8f3]">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* معلومات التواصل */}
            <div className="space-y-6 fade-in-up">
              <div>
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-2" style={{fontFamily:'Cairo,sans-serif'}}>معلومات التواصل</h2>
                <div className="gold-accent-line mb-6"></div>
              </div>

              <div className="grid gap-4">
                <a href="tel:+966500000000" className="flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow group">
                  <div className="w-12 h-12 bg-[#1a3d2b] rounded-xl flex items-center justify-center group-hover:bg-[#c9a84c] transition-colors">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1" style={{fontFamily:'Cairo,sans-serif'}}>اتصل بنا</p>
                    <p className="font-bold text-[#1a3d2b] text-lg" dir="ltr">+966 50 000 0000</p>
                  </div>
                </a>

                <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow group">
                  <div className="w-12 h-12 bg-[#25D366] rounded-xl flex items-center justify-center">
                    <MessageCircle className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1" style={{fontFamily:'Cairo,sans-serif'}}>واتساب</p>
                    <p className="font-bold text-[#1a3d2b] text-lg" dir="ltr">+966 50 000 0000</p>
                  </div>
                </a>

                <div className="flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm">
                  <div className="w-12 h-12 bg-[#1a3d2b]/10 rounded-xl flex items-center justify-center">
                    <MapPin className="w-5 h-5 text-[#1a3d2b]" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1" style={{fontFamily:'Cairo,sans-serif'}}>نخدم جميع مناطق</p>
                    <p className="font-bold text-[#1a3d2b]" style={{fontFamily:'Cairo,sans-serif'}}>المملكة العربية السعودية</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 bg-white rounded-2xl p-5 shadow-sm">
                  <div className="w-12 h-12 bg-[#1a3d2b]/10 rounded-xl flex items-center justify-center">
                    <Clock className="w-5 h-5 text-[#1a3d2b]" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1" style={{fontFamily:'Cairo,sans-serif'}}>ساعات العمل</p>
                    <p className="font-bold text-[#1a3d2b]" style={{fontFamily:'Cairo,sans-serif'}}>السبت - الخميس: 8ص - 10م</p>
                  </div>
                </div>
              </div>

              {/* أزرار CTA كبيرة */}
              <div className="grid grid-cols-2 gap-4 pt-4">
                <a href="tel:+966500000000" className="flex flex-col items-center gap-2 bg-[#1a3d2b] text-white p-5 rounded-2xl hover:bg-[#2d6a4f] transition-colors text-center">
                  <Phone className="w-7 h-7" />
                  <span className="font-bold" style={{fontFamily:'Cairo,sans-serif'}}>اتصل الآن</span>
                  <span className="text-white/60 text-xs">رد فوري</span>
                </a>
                <a href="https://wa.me/966500000000" target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 bg-[#25D366] text-white p-5 rounded-2xl hover:bg-[#20bd5a] transition-colors text-center">
                  <MessageCircle className="w-7 h-7" />
                  <span className="font-bold" style={{fontFamily:'Cairo,sans-serif'}}>واتساب</span>
                  <span className="text-white/60 text-xs">متاح 24/7</span>
                </a>
              </div>
            </div>

            {/* نموذج التواصل */}
            <div className="fade-in-up">
              <div className="bg-white rounded-3xl p-8 shadow-sm">
                <h2 className="text-2xl font-extrabold text-[#1a3d2b] mb-2" style={{fontFamily:'Cairo,sans-serif'}}>أرسل لنا رسالة</h2>
                <div className="gold-accent-line mb-6"></div>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5" style={{fontFamily:'Cairo,sans-serif'}}>الاسم *</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        placeholder="اسمك الكريم"
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3d2b] focus:ring-2 focus:ring-[#1a3d2b]/10 transition-all"
                        style={{fontFamily:'Tajawal,sans-serif'}}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5" style={{fontFamily:'Cairo,sans-serif'}}>رقم الجوال *</label>
                      <input
                        type="tel"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        placeholder="05xxxxxxxx"
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3d2b] focus:ring-2 focus:ring-[#1a3d2b]/10 transition-all"
                        dir="ltr"
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5" style={{fontFamily:'Cairo,sans-serif'}}>المدينة</label>
                      <input
                        type="text"
                        value={form.city}
                        onChange={(e) => setForm({ ...form, city: e.target.value })}
                        placeholder="مدينتك"
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3d2b] focus:ring-2 focus:ring-[#1a3d2b]/10 transition-all"
                        style={{fontFamily:'Tajawal,sans-serif'}}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1.5" style={{fontFamily:'Cairo,sans-serif'}}>الخدمة المطلوبة</label>
                      <select
                        value={form.service}
                        onChange={(e) => setForm({ ...form, service: e.target.value })}
                        className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3d2b] focus:ring-2 focus:ring-[#1a3d2b]/10 transition-all bg-white"
                        style={{fontFamily:'Tajawal,sans-serif'}}
                      >
                        <option value="">اختر الخدمة</option>
                        <option value="supply">توريد نخيل</option>
                        <option value="planting">زراعة نخيل</option>
                        <option value="transport">نقل نخيل</option>
                        <option value="large">نخيل كبير</option>
                        <option value="villas">نخيل للفلل</option>
                        <option value="government">مشاريع حكومية</option>
                        <option value="landscaping">تنسيق مواقع</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-1.5" style={{fontFamily:'Cairo,sans-serif'}}>تفاصيل الطلب</label>
                    <textarea
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      placeholder="اكتب تفاصيل طلبك هنا..."
                      rows={4}
                      className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-[#1a3d2b] focus:ring-2 focus:ring-[#1a3d2b]/10 transition-all resize-none"
                      style={{fontFamily:'Tajawal,sans-serif'}}
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-[#1a3d2b] text-white py-4 rounded-xl font-bold text-base hover:bg-[#2d6a4f] active:scale-[0.98] transition-all disabled:opacity-60"
                    style={{fontFamily:'Cairo,sans-serif'}}
                  >
                    {loading ? "جاري الإرسال..." : "إرسال الرسالة"}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
